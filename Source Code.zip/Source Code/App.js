import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { AuthProvider } from './src/context/AuthContext';
import { CartProvider } from './src/context/CartContext';
import AppNavigator from './src/navigation/AppNavigator';
import SplashScreen from './src/screens/SplashScreen';
import WelcomeScreen from './src/screens/WelcomeScreen';

// 3 trạng thái: 'splash' → 'welcome' → 'app'
const App = () => {
  const [screen, setScreen] = useState('splash');

  if (screen === 'splash') {
    return <SplashScreen onDone={() => setScreen('welcome')} />;
  }

  if (screen === 'welcome') {
    return <WelcomeScreen onDone={() => setScreen('app')} />;
  }

  return (
    <AuthProvider>
      <CartProvider>
        <NavigationContainer>
          <AppNavigator />
        </NavigationContainer>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;
