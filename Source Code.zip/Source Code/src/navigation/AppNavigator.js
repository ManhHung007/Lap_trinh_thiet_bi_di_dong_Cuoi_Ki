import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import ProductListScreen from '../screens/ProductListScreen';
import ProductDetailScreen from '../screens/ProductDetailScreen';
import CartScreen from '../screens/CartScreen';
import ProfileScreen from '../screens/ProfileScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import OrdersScreen from '../screens/OrdersScreen';
import PaymentScreen from '../screens/PaymentScreen';
import AddressScreen from '../screens/AddressScreen';
import NotificationScreen from '../screens/NotificationScreen';
import SecurityScreen from '../screens/SecurityScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import { SupportScreen, RatingScreen } from '../screens/SupportAndRatingScreen';

import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const AuthStack = createNativeStackNavigator();

const AuthNavigator = () => (
  <AuthStack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
    <AuthStack.Screen name="Login" component={LoginScreen} />
    <AuthStack.Screen name="Register" component={RegisterScreen} />
  </AuthStack.Navigator>
);

const HomeStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Home" component={HomeScreen} />
    <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
    <Stack.Screen name="ProductList" component={ProductListScreen} />
  </Stack.Navigator>
);

const ProductStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="ProductList" component={ProductListScreen} />
    <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
  </Stack.Navigator>
);

const CartStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Cart" component={CartScreen} />
    <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
  </Stack.Navigator>
);

// Profile stack gồm tất cả màn hình con
const ProfileStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
    <Stack.Screen name="ProfileMain" component={ProfileScreen} />
    <Stack.Screen name="Orders" component={OrdersScreen} />
    <Stack.Screen name="Payment" component={PaymentScreen} />
    <Stack.Screen name="Address" component={AddressScreen} />
    <Stack.Screen name="Notification" component={NotificationScreen} />
    <Stack.Screen name="Security" component={SecurityScreen} />
    <Stack.Screen name="Support" component={SupportScreen} />
    <Stack.Screen name="Rating" component={RatingScreen} />
    <Stack.Screen name="EditProfile" component={EditProfileScreen} />
  </Stack.Navigator>
);

const TabIcon = ({ label, emoji, focused, badgeCount }) => (
  <View style={tabStyles.wrap}>
    <Text style={[tabStyles.emoji, { opacity: focused ? 1 : 0.45 }]}>{emoji}</Text>
    {badgeCount > 0 && (
      <View style={tabStyles.badge}>
        <Text style={tabStyles.badgeText}>{badgeCount > 9 ? '9+' : badgeCount}</Text>
      </View>
    )}
    <Text style={[tabStyles.label, { color: focused ? '#4f8eff' : '#555' }]}>{label}</Text>
  </View>
);

const tabStyles = StyleSheet.create({
  wrap: { alignItems: 'center', position: 'relative', paddingTop: 4 },
  emoji: { fontSize: 22 },
  label: { fontSize: 10, marginTop: 2 },
  badge: { position: 'absolute', top: -2, right: -10, backgroundColor: '#e94040', borderRadius: 8, minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  badgeText: { color: '#fff', fontSize: 9, fontWeight: '700' },
});

const MainNavigator = () => {
  const { totalItems } = useCart();
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: '#12121a', borderTopWidth: 1, borderTopColor: '#22223a', height: 72, paddingBottom: 12 },
        tabBarShowLabel: false,
      }}
    >
      <Tab.Screen name="HomeTab" component={HomeStack}
        options={{ tabBarIcon: ({ focused }) => <TabIcon label="Trang chủ" emoji="🏠" focused={focused} /> }} />
      <Tab.Screen name="ProductsTab" component={ProductStack}
        options={{ tabBarIcon: ({ focused }) => <TabIcon label="Sản phẩm" emoji="📋" focused={focused} /> }} />
      <Tab.Screen name="CartTab" component={CartStack}
        options={{ tabBarIcon: ({ focused }) => <TabIcon label="Giỏ hàng" emoji="🛒" focused={focused} badgeCount={totalItems} /> }} />
      <Tab.Screen name="ProfileTab" component={ProfileStack}
        options={{ tabBarIcon: ({ focused }) => <TabIcon label="Tài khoản" emoji="👤" focused={focused} /> }} />
    </Tab.Navigator>
  );
};

const AppNavigator = () => {
  const { user } = useAuth();
  return user ? <MainNavigator /> : <AuthNavigator />;
};

export default AppNavigator;
