import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

const DEMO_ACCOUNTS = [
  { email: 'user@techshop.vn', password: '123456', name: 'Nguyễn Văn A', avatar: 'NA', phone: '0912 345 678', gender: 'male', birthday: '01/01/1995' },
  { email: 'admin@techshop.vn', password: 'admin123', name: 'Admin Shop', avatar: 'AD', phone: '0987 654 321', gender: 'male', birthday: '15/06/1990' },
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [accounts, setAccounts] = useState(DEMO_ACCOUNTS);

  const login = async (email, password) => {
    setLoading(true);
    setError('');
    await new Promise(res => setTimeout(res, 1000));
    const found = accounts.find(
      acc => acc.email === email.trim().toLowerCase() && acc.password === password
    );
    if (found) {
      setUser(found);
      setLoading(false);
      return true;
    } else {
      setError('Email hoặc mật khẩu không đúng');
      setLoading(false);
      return false;
    }
  };

  const register = (newUser) => {
    // Kiểm tra email đã tồn tại chưa
    const exists = accounts.find(
      acc => acc.email === newUser.email.toLowerCase()
    );
    if (exists) return 'duplicate';

    const account = {
      ...newUser,
      email: newUser.email.toLowerCase(),
      password: newUser.password,
      gender: newUser.gender || 'other',
      birthday: newUser.birthday || '',
    };
    setAccounts(prev => [...prev, account]);
    return 'ok';
  };

  // Cập nhật thông tin cá nhân
  const updateProfile = (updatedFields) => {
    const updated = { ...user, ...updatedFields };
    // Tự động cập nhật avatar từ 2 chữ đầu tên
    if (updatedFields.name) {
      const words = updatedFields.name.trim().split(' ');
      updated.avatar = words.length >= 2
        ? (words[0][0] + words[words.length - 1][0]).toUpperCase()
        : words[0].slice(0, 2).toUpperCase();
    }
    setUser(updated);
    setAccounts(prev => prev.map(acc =>
      acc.email === user.email ? { ...acc, ...updated } : acc
    ));
  };

  const logout = () => {
    setUser(null);
    setError('');
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, login, logout, register, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
