import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, TextInput, Alert, Modal,
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const GENDERS = [
  { id: 'male',   label: 'Nam',   icon: '👨' },
  { id: 'female', label: 'Nữ',    icon: '👩' },
  { id: 'other',  label: 'Khác',  icon: '🧑' },
];

const EditProfileScreen = ({ navigation }) => {
  const { user, updateProfile } = useAuth();

  const [name, setName]         = useState(user?.name || '');
  const [phone, setPhone]       = useState(user?.phone || '');
  const [email, setEmail]       = useState(user?.email || '');
  const [birthday, setBirthday] = useState(user?.birthday || '');
  const [gender, setGender]     = useState(user?.gender || 'male');
  const [saving, setSaving]     = useState(false);
  const [showGenderModal, setShowGenderModal] = useState(false);

  const errors = {};
  const validate = () => {
    const e = {};
    if (!name.trim()) e.name = 'Vui lòng nhập họ tên';
    if (phone && !/^[0-9\s]{9,11}$/.test(phone.replace(/\s/g,'')))
      e.phone = 'Số điện thoại không hợp lệ';
    if (birthday && !/^\d{2}\/\d{2}\/\d{4}$/.test(birthday))
      e.birthday = 'Định dạng: DD/MM/YYYY';
    return e;
  };

  const [fieldErrors, setFieldErrors] = useState({});

  const handleSave = async () => {
    const e = validate();
    if (Object.keys(e).length > 0) { setFieldErrors(e); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    updateProfile({ name: name.trim(), phone, birthday, gender });
    setSaving(false);
    Alert.alert('✅ Thành công', 'Thông tin đã được cập nhật!', [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  // Avatar preview từ tên
  const avatarText = (() => {
    const words = name.trim().split(' ').filter(Boolean);
    if (words.length >= 2) return (words[0][0] + words[words.length-1][0]).toUpperCase();
    return (words[0] || 'U').slice(0,2).toUpperCase();
  })();

  const selectedGender = GENDERS.find(g => g.id === gender);

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>Sửa thông tin</Text>
        <TouchableOpacity
          style={[s.saveBtn, saving && s.saveBtnLoading]}
          onPress={handleSave}
          disabled={saving}
        >
          <Text style={s.saveBtnText}>{saving ? '...' : 'Lưu'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Avatar */}
        <View style={s.avatarSection}>
          <View style={s.avatarWrap}>
            <View style={s.avatar}>
              <Text style={s.avatarText}>{avatarText}</Text>
            </View>
            <TouchableOpacity style={s.cameraBtn}>
              <Text style={s.cameraIcon}>📷</Text>
            </TouchableOpacity>
          </View>
          <Text style={s.avatarHint}>Nhấn vào icon 📷 để đổi ảnh đại diện</Text>
        </View>

        {/* Form */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>Thông tin cá nhân</Text>

          {/* Họ tên */}
          <Text style={s.label}>Họ và tên <Text style={s.required}>*</Text></Text>
          <View style={[s.inputWrap, fieldErrors.name && s.inputError]}>
            <Text style={s.inputIcon}>👤</Text>
            <TextInput
              style={s.input}
              value={name}
              onChangeText={v => { setName(v); setFieldErrors(e => ({...e, name:''})); }}
              placeholder="Nguyễn Văn A"
              placeholderTextColor="#444"
              autoCapitalize="words"
            />
          </View>
          {!!fieldErrors.name && <Text style={s.errorText}>⚠ {fieldErrors.name}</Text>}

          {/* Email (readonly) */}
          <Text style={s.label}>Email</Text>
          <View style={[s.inputWrap, s.inputDisabled]}>
            <Text style={s.inputIcon}>✉️</Text>
            <TextInput
              style={[s.input, { color: '#555' }]}
              value={email}
              editable={false}
            />
            <View style={s.lockBadge}>
              <Text style={s.lockText}>🔒</Text>
            </View>
          </View>
          <Text style={s.hintText}>Email không thể thay đổi</Text>

          {/* Số điện thoại */}
          <Text style={s.label}>Số điện thoại</Text>
          <View style={[s.inputWrap, fieldErrors.phone && s.inputError]}>
            <Text style={s.inputIcon}>📱</Text>
            <TextInput
              style={s.input}
              value={phone}
              onChangeText={v => { setPhone(v); setFieldErrors(e => ({...e, phone:''})); }}
              placeholder="0912 345 678"
              placeholderTextColor="#444"
              keyboardType="phone-pad"
            />
          </View>
          {!!fieldErrors.phone && <Text style={s.errorText}>⚠ {fieldErrors.phone}</Text>}

          {/* Ngày sinh */}
          <Text style={s.label}>Ngày sinh</Text>
          <View style={[s.inputWrap, fieldErrors.birthday && s.inputError]}>
            <Text style={s.inputIcon}>🎂</Text>
            <TextInput
              style={s.input}
              value={birthday}
              onChangeText={v => { setBirthday(v); setFieldErrors(e => ({...e, birthday:''})); }}
              placeholder="DD/MM/YYYY"
              placeholderTextColor="#444"
              keyboardType="numeric"
              maxLength={10}
            />
          </View>
          {!!fieldErrors.birthday && <Text style={s.errorText}>⚠ {fieldErrors.birthday}</Text>}

          {/* Giới tính */}
          <Text style={s.label}>Giới tính</Text>
          <TouchableOpacity
            style={s.inputWrap}
            onPress={() => setShowGenderModal(true)}
            activeOpacity={0.8}
          >
            <Text style={s.inputIcon}>{selectedGender?.icon}</Text>
            <Text style={[s.input, { lineHeight: 48, color: '#fff' }]}>
              {selectedGender?.label}
            </Text>
            <Text style={{ color: '#444', fontSize: 18 }}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Info box */}
        <View style={s.infoBox}>
          <Text style={s.infoIcon}>ℹ️</Text>
          <Text style={s.infoText}>
            Thông tin cá nhân của bạn được bảo mật và chỉ dùng để cải thiện trải nghiệm mua sắm.
          </Text>
        </View>

        {/* Save button */}
        <TouchableOpacity
          style={[s.saveFullBtn, saving && s.saveFullBtnLoading]}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.85}
        >
          <Text style={s.saveFullBtnText}>
            {saving ? 'Đang lưu...' : '💾 Lưu thay đổi'}
          </Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Gender picker modal */}
      <Modal visible={showGenderModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modal}>
            <View style={s.modalHandle} />
            <Text style={s.modalTitle}>Chọn giới tính</Text>
            {GENDERS.map(g => (
              <TouchableOpacity
                key={g.id}
                style={[s.genderRow, gender === g.id && s.genderRowActive]}
                onPress={() => { setGender(g.id); setShowGenderModal(false); }}
              >
                <Text style={s.genderIcon}>{g.icon}</Text>
                <Text style={[s.genderLabel, gender === g.id && s.genderLabelActive]}>
                  {g.label}
                </Text>
                {gender === g.id && <Text style={s.genderCheck}>✓</Text>}
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={s.modalCancel} onPress={() => setShowGenderModal(false)}>
              <Text style={s.modalCancelText}>Hủy</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 14,
  },
  backBtn: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#fff' },
  saveBtn: { backgroundColor: '#4f8eff', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 8 },
  saveBtnLoading: { backgroundColor: '#1a2a4a' },
  saveBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },

  // Avatar
  avatarSection: { alignItems: 'center', paddingVertical: 24 },
  avatarWrap: { position: 'relative', marginBottom: 10 },
  avatar: { width: 90, height: 90, borderRadius: 28, backgroundColor: '#1a3a8f', alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#2a5abf' },
  avatarText: { fontSize: 32, fontWeight: '800', color: '#fff' },
  cameraBtn: { position: 'absolute', bottom: -4, right: -4, width: 32, height: 32, borderRadius: 16, backgroundColor: '#4f8eff', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#0a0a0f' },
  cameraIcon: { fontSize: 16 },
  avatarHint: { fontSize: 12, color: '#555' },

  // Section
  section: { paddingHorizontal: 20, marginBottom: 16 },
  sectionTitle: { fontSize: 13, color: '#555', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 16 },

  // Form fields
  label: { fontSize: 13, fontWeight: '600', color: '#aaa', marginBottom: 8 },
  required: { color: '#e94040' },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#12121a', borderRadius: 14,
    borderWidth: 1, borderColor: '#1e1e30',
    paddingHorizontal: 14, marginBottom: 4, gap: 10,
    minHeight: 52,
  },
  inputError: { borderColor: '#e94040' },
  inputDisabled: { opacity: 0.6 },
  inputIcon: { fontSize: 18 },
  input: { flex: 1, color: '#fff', fontSize: 15, paddingVertical: 14 },
  lockBadge: { backgroundColor: '#1a1a2e', borderRadius: 8, padding: 4 },
  lockText: { fontSize: 14 },
  errorText: { fontSize: 12, color: '#e94040', marginBottom: 10, marginLeft: 4 },
  hintText: { fontSize: 11, color: '#444', marginBottom: 14, marginLeft: 4 },

  // Info box
  infoBox: { flexDirection: 'row', gap: 10, marginHorizontal: 20, backgroundColor: '#0d1b3e', borderRadius: 14, borderWidth: 1, borderColor: '#1a3a8f', padding: 14, marginBottom: 20 },
  infoIcon: { fontSize: 18 },
  infoText: { flex: 1, fontSize: 12, color: '#6a9adf', lineHeight: 18 },

  // Save full button
  saveFullBtn: { marginHorizontal: 20, backgroundColor: '#4f8eff', borderRadius: 16, paddingVertical: 18, alignItems: 'center' },
  saveFullBtnLoading: { backgroundColor: '#1a2a4a' },
  saveFullBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },

  // Gender modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#12121a', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, borderWidth: 1, borderColor: '#1e1e30', paddingBottom: 36 },
  modalHandle: { width: 40, height: 4, backgroundColor: '#2a2a45', borderRadius: 2, alignSelf: 'center', marginBottom: 18 },
  modalTitle: { fontSize: 17, fontWeight: '700', color: '#fff', marginBottom: 16 },
  genderRow: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', marginBottom: 10, gap: 14, backgroundColor: '#0e0e18' },
  genderRowActive: { borderColor: '#4f8eff', backgroundColor: '#0d1b3e' },
  genderIcon: { fontSize: 24 },
  genderLabel: { flex: 1, fontSize: 16, color: '#ccc', fontWeight: '500' },
  genderLabelActive: { color: '#fff', fontWeight: '700' },
  genderCheck: { fontSize: 18, color: '#4f8eff', fontWeight: '700' },
  modalCancel: { paddingVertical: 14, alignItems: 'center' },
  modalCancelText: { color: '#555', fontSize: 14 },
});

export default EditProfileScreen;
