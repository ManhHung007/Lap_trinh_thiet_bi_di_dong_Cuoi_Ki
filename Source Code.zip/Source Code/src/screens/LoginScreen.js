import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  SafeAreaView, StatusBar, KeyboardAvoidingView,
  Platform, ActivityIndicator, ScrollView,
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const LoginScreen = ({ navigation }) => {
  const { login, loading, error } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) return;
    await login(email, password);
  };

  const fillDemo = (type) => {
    if (type === 'user') { setEmail('user@techshop.vn'); setPassword('123456'); }
    else { setEmail('admin@techshop.vn'); setPassword('admin123'); }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Logo */}
          <View style={styles.logoWrap}>
            <View style={styles.logo}>
              <Text style={styles.logoIcon}>⚡</Text>
            </View>
            <Text style={styles.appName}>TechShop</Text>
            <Text style={styles.appTagline}>Thiết bị điện tử chính hãng</Text>
          </View>

          {/* Form */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Đăng nhập</Text>
            <Text style={styles.cardSub}>Chào mừng bạn trở lại 👋</Text>

            {!!error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>⚠️ {error}</Text>
              </View>
            )}

            <Text style={styles.label}>Email</Text>
            <View style={styles.inputWrap}>
              <Text style={styles.inputIcon}>✉️</Text>
              <TextInput
                style={styles.input}
                placeholder="nhập email của bạn"
                placeholderTextColor="#444"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            <Text style={styles.label}>Mật khẩu</Text>
            <View style={styles.inputWrap}>
              <Text style={styles.inputIcon}>🔒</Text>
              <TextInput
                style={styles.input}
                placeholder="nhập mật khẩu"
                placeholderTextColor="#444"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPass}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowPass(s => !s)} style={styles.eyeBtn}>
                <Text style={styles.eyeIcon}>{showPass ? '🙈' : '👁️'}</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.forgotWrap}>
              <Text style={styles.forgotText}>Quên mật khẩu?</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.loginBtn, (!email || !password) && styles.loginBtnDisabled]}
              onPress={handleLogin}
              disabled={loading || !email || !password}
              activeOpacity={0.85}
            >
              {loading
                ? <ActivityIndicator color="#fff" />
                : <Text style={styles.loginBtnText}>Đăng nhập</Text>
              }
            </TouchableOpacity>

            <View style={styles.dividerRow}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>hoặc thử nhanh</Text>
              <View style={styles.dividerLine} />
            </View>

            <View style={styles.demoRow}>
              <TouchableOpacity style={styles.demoBtn} onPress={() => fillDemo('user')}>
                <Text style={styles.demoBtnText}>👤 User demo</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.demoBtn, styles.demoBtnAdmin]} onPress={() => fillDemo('admin')}>
                <Text style={[styles.demoBtnText, { color: '#f5a623' }]}>🛡️ Admin demo</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Đăng ký */}
          <View style={styles.registerRow}>
            <Text style={styles.registerText}>Chưa có tài khoản? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={styles.registerLink}>Đăng ký ngay →</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  container: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  logoWrap: { alignItems: 'center', marginBottom: 36 },
  logo: {
    width: 72, height: 72, backgroundColor: '#1a3a8f',
    borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  logoIcon: { fontSize: 34 },
  appName: { fontSize: 28, fontWeight: '800', color: '#fff', letterSpacing: 1 },
  appTagline: { fontSize: 13, color: '#555', marginTop: 4 },
  card: {
    backgroundColor: '#12121a', borderRadius: 24,
    borderWidth: 1, borderColor: '#1e1e30', padding: 24, marginBottom: 24,
  },
  cardTitle: { fontSize: 22, fontWeight: '700', color: '#fff', marginBottom: 4 },
  cardSub: { fontSize: 14, color: '#666', marginBottom: 20 },
  errorBox: {
    backgroundColor: '#2a1212', borderRadius: 12,
    borderWidth: 1, borderColor: '#4a2020', padding: 12, marginBottom: 16,
  },
  errorText: { color: '#e94040', fontSize: 13 },
  label: { fontSize: 13, fontWeight: '600', color: '#aaa', marginBottom: 8 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#1a1a2e', borderRadius: 14,
    borderWidth: 1, borderColor: '#2a2a45',
    paddingHorizontal: 14, marginBottom: 16, gap: 10,
  },
  inputIcon: { fontSize: 16 },
  input: { flex: 1, color: '#fff', fontSize: 15, paddingVertical: 14 },
  eyeBtn: { padding: 4 },
  eyeIcon: { fontSize: 16 },
  forgotWrap: { alignSelf: 'flex-end', marginBottom: 20, marginTop: -8 },
  forgotText: { fontSize: 13, color: '#4f8eff' },
  loginBtn: {
    backgroundColor: '#4f8eff', borderRadius: 14,
    paddingVertical: 16, alignItems: 'center', marginBottom: 20,
  },
  loginBtnDisabled: { backgroundColor: '#1a2a4a' },
  loginBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 10 },
  dividerLine: { flex: 1, height: 1, backgroundColor: '#1e1e30' },
  dividerText: { fontSize: 12, color: '#444' },
  demoRow: { flexDirection: 'row', gap: 10 },
  demoBtn: {
    flex: 1, backgroundColor: '#1a1a2e', borderRadius: 12,
    borderWidth: 1, borderColor: '#2a4a7a', paddingVertical: 12, alignItems: 'center',
  },
  demoBtnAdmin: { borderColor: '#4a3a1a' },
  demoBtnText: { fontSize: 12, color: '#4f8eff', fontWeight: '600' },
  registerRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  registerText: { fontSize: 14, color: '#555' },
  registerLink: { fontSize: 14, color: '#4f8eff', fontWeight: '700' },
});

export default LoginScreen;
