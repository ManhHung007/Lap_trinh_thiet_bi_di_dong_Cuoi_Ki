import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, SafeAreaView, StatusBar, Alert,
} from 'react-native';

const initialCards = [
  { id: 1, type: 'visa', number: '•••• •••• •••• 4242', name: 'NGUYEN VAN A', expiry: '12/27', color: '#1a3a8f', default: true },
  { id: 2, type: 'mastercard', number: '•••• •••• •••• 8888', name: 'NGUYEN VAN A', expiry: '08/26', color: '#2a1a1a', default: false },
];

const wallets = [
  { id: 'momo', name: 'MoMo', emoji: '💜', connected: true, balance: '250.000đ' },
  { id: 'zalopay', name: 'ZaloPay', emoji: '💙', connected: true, balance: '1.200.000đ' },
  { id: 'vnpay', name: 'VNPay', emoji: '🔴', connected: false, balance: null },
  { id: 'cod', name: 'Tiền mặt (COD)', emoji: '💵', connected: true, balance: null },
];

const PaymentScreen = ({ navigation }) => {
  const [cards, setCards] = useState(initialCards);
  const [tab, setTab] = useState('card');

  const setDefault = (id) => {
    setCards(prev => prev.map(c => ({ ...c, default: c.id === id })));
  };

  const deleteCard = (id) => {
    Alert.alert('Xóa thẻ?', 'Bạn có chắc muốn xóa thẻ này?', [
      { text: 'Hủy', style: 'cancel' },
      { text: 'Xóa', style: 'destructive', onPress: () => setCards(prev => prev.filter(c => c.id !== id)) },
    ]);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Thanh toán</Text>
        <View style={{ width: 38 }} />
      </View>

      {/* Tabs */}
      <View style={s.tabRow}>
        <TouchableOpacity style={[s.tab, tab === 'card' && s.tabActive]} onPress={() => setTab('card')}>
          <Text style={[s.tabText, tab === 'card' && s.tabTextActive]}>💳 Thẻ ngân hàng</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.tab, tab === 'wallet' && s.tabActive]} onPress={() => setTab('wallet')}>
          <Text style={[s.tabText, tab === 'wallet' && s.tabTextActive]}>📱 Ví điện tử</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 12 }}>
        {tab === 'card' ? (
          <>
            {cards.map(card => (
              <View key={card.id} style={[s.cardItem, { backgroundColor: card.color }]}>
                <View style={s.cardTop}>
                  <Text style={s.cardType}>{card.type === 'visa' ? 'VISA' : 'MASTERCARD'}</Text>
                  {card.default && (
                    <View style={s.defaultBadge}><Text style={s.defaultText}>Mặc định</Text></View>
                  )}
                </View>
                <Text style={s.cardNumber}>{card.number}</Text>
                <View style={s.cardBottom}>
                  <View>
                    <Text style={s.cardLabel}>Chủ thẻ</Text>
                    <Text style={s.cardName}>{card.name}</Text>
                  </View>
                  <View>
                    <Text style={s.cardLabel}>Hết hạn</Text>
                    <Text style={s.cardName}>{card.expiry}</Text>
                  </View>
                  <View style={s.cardActions}>
                    {!card.default && (
                      <TouchableOpacity style={s.actionBtn} onPress={() => setDefault(card.id)}>
                        <Text style={s.actionText}>Đặt mặc định</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity style={[s.actionBtn, s.deleteBtn]} onPress={() => deleteCard(card.id)}>
                      <Text style={[s.actionText, { color: '#e94040' }]}>Xóa</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
            <TouchableOpacity style={s.addBtn} onPress={() => Alert.alert('Thêm thẻ', 'Chức năng đang phát triển')}>
              <Text style={s.addIcon}>+</Text>
              <Text style={s.addText}>Thêm thẻ mới</Text>
            </TouchableOpacity>
          </>
        ) : (
          wallets.map(w => (
            <View key={w.id} style={s.walletItem}>
              <Text style={s.walletEmoji}>{w.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={s.walletName}>{w.name}</Text>
                {w.balance && <Text style={s.walletBalance}>Số dư: {w.balance}</Text>}
              </View>
              <TouchableOpacity
                style={[s.connectBtn, w.connected && s.connectedBtn]}
                onPress={() => Alert.alert(w.connected ? 'Ngắt kết nối?' : 'Kết nối ' + w.name, '', [
                  { text: 'Hủy', style: 'cancel' },
                  { text: w.connected ? 'Ngắt' : 'Kết nối', onPress: () => {} },
                ])}
              >
                <Text style={[s.connectText, w.connected && s.connectedText]}>
                  {w.connected ? 'Đã kết nối' : 'Kết nối'}
                </Text>
              </TouchableOpacity>
            </View>
          ))
        )}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },
  tabRow: { flexDirection: 'row', marginHorizontal: 16, marginBottom: 16, backgroundColor: '#12121a', borderRadius: 14, padding: 4, gap: 4 },
  tab: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  tabActive: { backgroundColor: '#1a3a8f' },
  tabText: { fontSize: 13, color: '#555', fontWeight: '500' },
  tabTextActive: { color: '#fff', fontWeight: '700' },
  cardItem: { borderRadius: 20, padding: 20, minHeight: 160 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  cardType: { color: '#fff', fontWeight: '800', fontSize: 16, letterSpacing: 2 },
  defaultBadge: { backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  defaultText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  cardNumber: { color: '#fff', fontSize: 18, fontWeight: '600', letterSpacing: 2, marginBottom: 20 },
  cardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  cardLabel: { color: 'rgba(255,255,255,0.5)', fontSize: 10, marginBottom: 2 },
  cardName: { color: '#fff', fontSize: 13, fontWeight: '600' },
  cardActions: { gap: 6 },
  actionBtn: { backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  deleteBtn: { backgroundColor: 'rgba(233,64,64,0.2)' },
  actionText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  addBtn: { borderWidth: 1.5, borderColor: '#2a2a45', borderStyle: 'dashed', borderRadius: 16, padding: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  addIcon: { fontSize: 24, color: '#4f8eff' },
  addText: { color: '#4f8eff', fontSize: 15, fontWeight: '600' },
  walletItem: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14 },
  walletEmoji: { fontSize: 32 },
  walletName: { fontSize: 15, color: '#fff', fontWeight: '600', marginBottom: 2 },
  walletBalance: { fontSize: 12, color: '#4caf50' },
  connectBtn: { backgroundColor: '#1a1a2e', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: '#2a2a45' },
  connectedBtn: { backgroundColor: '#0d2a0d', borderColor: '#2a4a2a' },
  connectText: { fontSize: 12, color: '#888', fontWeight: '600' },
  connectedText: { color: '#22c55e' },
});

export default PaymentScreen;
