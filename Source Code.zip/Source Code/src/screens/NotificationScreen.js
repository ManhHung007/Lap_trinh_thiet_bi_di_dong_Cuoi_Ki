import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Switch,
} from 'react-native';

const groups = [
  {
    title: 'Đơn hàng',
    items: [
      { id: 'order_status', label: 'Trạng thái đơn hàng', sub: 'Nhận thông báo khi đơn hàng thay đổi trạng thái', default: true },
      { id: 'order_delivered', label: 'Giao hàng thành công', sub: 'Thông báo khi hàng đã đến nơi', default: true },
      { id: 'order_cancel', label: 'Đơn hàng bị hủy', sub: 'Cảnh báo khi đơn hàng bị hủy', default: true },
    ],
  },
  {
    title: 'Khuyến mãi',
    items: [
      { id: 'promo_flash', label: 'Flash sale', sub: 'Ưu đãi chớp nhoáng chỉ trong vài giờ', default: true },
      { id: 'promo_voucher', label: 'Voucher mới', sub: 'Thông báo khi có voucher mới dành cho bạn', default: false },
      { id: 'promo_daily', label: 'Ưu đãi hàng ngày', sub: 'Tổng hợp khuyến mãi mỗi sáng', default: false },
    ],
  },
  {
    title: 'Hệ thống',
    items: [
      { id: 'sys_security', label: 'Bảo mật tài khoản', sub: 'Đăng nhập lạ, thay đổi mật khẩu', default: true },
      { id: 'sys_update', label: 'Cập nhật ứng dụng', sub: 'Thông báo khi có phiên bản mới', default: false },
      { id: 'sys_review', label: 'Nhắc nhở đánh giá', sub: 'Nhắc đánh giá sản phẩm đã mua', default: true },
    ],
  },
];

const NotificationScreen = ({ navigation }) => {
  const initState = {};
  groups.forEach(g => g.items.forEach(i => { initState[i.id] = i.default; }));
  const [settings, setSettings] = useState(initState);

  const toggle = (id) => setSettings(prev => ({ ...prev, [id]: !prev[id] }));

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Thông báo</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 20 }}>
        {/* Master toggle */}
        <View style={s.masterCard}>
          <Text style={s.masterIcon}>🔔</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.masterTitle}>Bật tất cả thông báo</Text>
            <Text style={s.masterSub}>Cho phép TechShop gửi thông báo</Text>
          </View>
          <Switch
            value={Object.values(settings).some(v => v)}
            onValueChange={(val) => {
              const newState = {};
              Object.keys(settings).forEach(k => { newState[k] = val; });
              setSettings(newState);
            }}
            trackColor={{ false: '#2a2a45', true: '#1a3a8f' }}
            thumbColor={Object.values(settings).some(v => v) ? '#4f8eff' : '#555'}
          />
        </View>

        {groups.map(group => (
          <View key={group.title}>
            <Text style={s.groupTitle}>{group.title}</Text>
            <View style={s.groupCard}>
              {group.items.map((item, i) => (
                <View key={item.id}>
                  <View style={s.row}>
                    <View style={{ flex: 1 }}>
                      <Text style={s.itemLabel}>{item.label}</Text>
                      <Text style={s.itemSub}>{item.sub}</Text>
                    </View>
                    <Switch
                      value={settings[item.id]}
                      onValueChange={() => toggle(item.id)}
                      trackColor={{ false: '#2a2a45', true: '#1a3a8f' }}
                      thumbColor={settings[item.id] ? '#4f8eff' : '#555'}
                    />
                  </View>
                  {i < group.items.length - 1 && <View style={s.divider} />}
                </View>
              ))}
            </View>
          </View>
        ))}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },
  masterCard: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14 },
  masterIcon: { fontSize: 28 },
  masterTitle: { fontSize: 15, fontWeight: '700', color: '#fff', marginBottom: 2 },
  masterSub: { fontSize: 12, color: '#666' },
  groupTitle: { fontSize: 12, color: '#555', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 },
  groupCard: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  itemLabel: { fontSize: 14, color: '#ddd', fontWeight: '500', marginBottom: 2 },
  itemSub: { fontSize: 12, color: '#555', lineHeight: 16 },
  divider: { height: 1, backgroundColor: '#1e1e30', marginHorizontal: 14 },
});

export default NotificationScreen;
