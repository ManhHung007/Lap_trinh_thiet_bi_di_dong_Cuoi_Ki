import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Image,
} from 'react-native';
import { products, categories, productImages } from '../data/products';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const HomeScreen = ({ navigation }) => {
  const [selectedCat, setSelectedCat] = useState('Tất cả');
  const { totalItems } = useCart();
  const { user } = useAuth();

  const filtered = selectedCat === 'Tất cả'
    ? products
    : products.filter(p => p.category === selectedCat);

  // Lời chào theo giờ
  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Chào buổi sáng ☀️';
    if (h < 18) return 'Chào buổi chiều 🌤';
    return 'Chào buổi tối 🌙';
  };

  // Lấy tên ngắn (tên đầu tiên)
  const firstName = user?.name?.split(' ').pop() || 'bạn';

  // Sản phẩm nổi bật cho banner
  const bannerProduct = products[4];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{getGreeting()}</Text>
            <Text style={styles.greetingName}>{firstName}</Text>
          </View>
          <TouchableOpacity style={styles.cartBtn} onPress={() => navigation.navigate('Cart')}>
            <Text style={styles.cartIcon}>🛒</Text>
            {totalItems > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{totalItems}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Search bar */}
        <TouchableOpacity
          style={styles.searchBar}
          onPress={() => navigation.navigate('ProductList')}
          activeOpacity={0.8}
        >
          <Text style={styles.searchIcon}>🔍</Text>
          <Text style={styles.searchText}>Tìm kiếm thiết bị điện tử...</Text>
        </TouchableOpacity>

        {/* Banner */}
        <TouchableOpacity
          style={styles.banner}
          onPress={() => navigation.navigate('ProductDetail', { product: bannerProduct })}
          activeOpacity={0.9}
        >
          <Image
            source={productImages[bannerProduct.imageKey]}
            style={styles.bannerImg}
            resizeMode="cover"
          />
          <View style={styles.bannerOverlay}>
            <View style={styles.bannerTag}>
              <Text style={styles.bannerTagText}>⚡ Ưu đãi hôm nay</Text>
            </View>
            <Text style={styles.bannerTitle}>{bannerProduct.name}</Text>
            <Text style={styles.bannerSub}>
              Giảm đến {Math.round((1 - bannerProduct.price / bannerProduct.oldPrice) * 100)}%
              — Chỉ còn {(bannerProduct.price / 1000000).toFixed(1)}M
            </Text>
            <View style={styles.bannerBtn}>
              <Text style={styles.bannerBtnText}>Mua ngay →</Text>
            </View>
          </View>
        </TouchableOpacity>

        {/* Flash sale mini */}
        <View style={styles.flashRow}>
          {products.slice(0, 3).map(p => (
            <TouchableOpacity
              key={p.id}
              style={styles.flashCard}
              onPress={() => navigation.navigate('ProductDetail', { product: p })}
              activeOpacity={0.85}
            >
              <Image source={productImages[p.imageKey]} style={styles.flashImg} resizeMode="cover" />
              <Text style={styles.flashPrice}>{(p.price / 1000000).toFixed(1)}M</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Categories */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Danh mục</Text>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.catScroll}
        >
          {categories.map(cat => (
            <TouchableOpacity
              key={cat}
              style={[styles.catChip, selectedCat === cat && styles.catChipActive]}
              onPress={() => setSelectedCat(cat)}
            >
              <Text style={[styles.catLabel, selectedCat === cat && styles.catLabelActive]}>
                {cat}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Products */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {selectedCat === 'Tất cả' ? 'Nổi bật' : selectedCat}
          </Text>
          <TouchableOpacity onPress={() => navigation.navigate('ProductList')}>
            <Text style={styles.seeAll}>Xem tất cả</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.productsContainer}>
          {filtered.reduce((rows, item, index) => {
            if (index % 2 === 0) {
              rows.push(
                <View key={index} style={styles.row}>
                  <ProductCard
                    product={item}
                    onPress={() => navigation.navigate('ProductDetail', { product: item })}
                  />
                  {filtered[index + 1] ? (
                    <ProductCard
                      product={filtered[index + 1]}
                      onPress={() => navigation.navigate('ProductDetail', { product: filtered[index + 1] })}
                    />
                  ) : (
                    <View style={{ flex: 1, margin: 6 }} />
                  )}
                </View>
              );
            }
            return rows;
          }, [])}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 },
  greeting: { fontSize: 13, color: '#888' },
  greetingName: { fontSize: 20, fontWeight: '700', color: '#fff', marginTop: 2 },
  cartBtn: { position: 'relative', padding: 8 },
  cartIcon: { fontSize: 24 },
  cartBadge: { position: 'absolute', top: 2, right: 2, backgroundColor: '#e94040', borderRadius: 8, minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  cartBadgeText: { color: '#fff', fontSize: 9, fontWeight: '700' },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1a1a2e', marginHorizontal: 20, marginBottom: 16, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: '#2a2a45', gap: 10 },
  searchIcon: { fontSize: 16 },
  searchText: { fontSize: 14, color: '#555' },

  // Banner
  banner: { marginHorizontal: 20, marginBottom: 16, borderRadius: 20, overflow: 'hidden', height: 180 },
  bannerImg: { position: 'absolute', width: '100%', height: '100%' },
  bannerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,30,0.6)', padding: 20, justifyContent: 'flex-end' },
  bannerTag: { backgroundColor: 'rgba(79,142,255,0.3)', alignSelf: 'flex-start', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, marginBottom: 6, borderWidth: 1, borderColor: '#4f8eff' },
  bannerTagText: { color: '#90caf9', fontSize: 11 },
  bannerTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 4 },
  bannerSub: { fontSize: 12, color: '#90caf9', marginBottom: 10 },
  bannerBtn: { backgroundColor: '#4f8eff', alignSelf: 'flex-start', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 8 },
  bannerBtnText: { color: '#fff', fontSize: 12, fontWeight: '600' },

  // Flash sale
  flashRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, marginBottom: 20 },
  flashCard: { flex: 1, backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', overflow: 'hidden' },
  flashImg: { width: '100%', height: 80, backgroundColor: '#1a1a2e' },
  flashPrice: { fontSize: 11, fontWeight: '700', color: '#4f8eff', padding: 6, textAlign: 'center' },

  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, marginBottom: 14 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#fff' },
  seeAll: { fontSize: 12, color: '#4f8eff' },
  catScroll: { paddingHorizontal: 14, paddingBottom: 16, gap: 8 },
  catChip: { backgroundColor: '#1a1a2e', borderWidth: 1, borderColor: '#2a2a45', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 8 },
  catChipActive: { backgroundColor: '#1a3a8f', borderColor: '#4f8eff' },
  catLabel: { fontSize: 12, color: '#ccc' },
  catLabelActive: { color: '#fff', fontWeight: '600' },
  productsContainer: { paddingHorizontal: 14 },
  row: { flexDirection: 'row' },
});

export default HomeScreen;
