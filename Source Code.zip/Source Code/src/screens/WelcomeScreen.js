import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, Dimensions, StatusBar, SafeAreaView,
} from 'react-native';

const { width } = Dimensions.get('window');

const slides = [
  {
    emoji: '⚡',
    bg: '#0d1b3e',
    accent: '#4f8eff',
    title: 'Chào mừng đến\nTechShop',
    sub: 'Khám phá hàng nghìn thiết bị điện tử\nchính hãng với giá tốt nhất thị trường.',
  },
  {
    emoji: '🛍️',
    bg: '#1a0d2e',
    accent: '#a855f7',
    title: 'Mua sắm\ndễ dàng hơn',
    sub: 'Chỉ vài thao tác đơn giản, sản phẩm\nsẽ đến tay bạn trong 2–3 ngày.',
  },
  {
    emoji: '🔒',
    bg: '#0d2e1a',
    accent: '#22c55e',
    title: 'An toàn &\nBảo mật',
    sub: 'Thanh toán an toàn, đổi trả dễ dàng\nvà hỗ trợ khách hàng 24/7.',
  },
];

const WelcomeScreen = ({ onDone }) => {
  const [current, setCurrent] = useState(0);
  const translateX = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const goTo = (index) => {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 180, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 280, useNativeDriver: true }),
    ]).start();
    setCurrent(index);
  };

  const next = () => {
    if (current < slides.length - 1) goTo(current + 1);
    else onDone();
  };

  const slide = slides[current];
  const isLast = current === slides.length - 1;

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: slide.bg }]}>
      <StatusBar barStyle="light-content" backgroundColor={slide.bg} />

      {/* Skip */}
      <View style={styles.topBar}>
        <View />
        {!isLast && (
          <TouchableOpacity onPress={onDone} style={styles.skipBtn}>
            <Text style={styles.skipText}>Bỏ qua</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Nội dung */}
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>

        {/* Vòng tròn nền */}
        <View style={[styles.circleOuter, { borderColor: slide.accent + '22' }]}>
          <View style={[styles.circleInner, { backgroundColor: slide.accent + '18' }]}>
            <View style={[styles.emojiBox, { backgroundColor: slide.accent + '30', borderColor: slide.accent + '55' }]}>
              <Text style={styles.emoji}>{slide.emoji}</Text>
            </View>
          </View>
        </View>

        {/* Text */}
        <Text style={styles.title}>{slide.title}</Text>
        <Text style={styles.sub}>{slide.sub}</Text>
      </Animated.View>

      {/* Dots */}
      <View style={styles.dotsRow}>
        {slides.map((_, i) => (
          <TouchableOpacity key={i} onPress={() => goTo(i)}>
            <Animated.View
              style={[
                styles.dot,
                i === current
                  ? [styles.dotActive, { backgroundColor: slide.accent, width: 28 }]
                  : styles.dotInactive,
              ]}
            />
          </TouchableOpacity>
        ))}
      </View>

      {/* Nút */}
      <View style={styles.btnWrap}>
        <TouchableOpacity
          style={[styles.nextBtn, { backgroundColor: slide.accent }]}
          onPress={next}
          activeOpacity={0.85}
        >
          <Text style={styles.nextBtnText}>
            {isLast ? 'Bắt đầu ngay  →' : 'Tiếp theo  →'}
          </Text>
        </TouchableOpacity>
      </View>

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1 },
  topBar: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: 24, paddingTop: 12, paddingBottom: 4,
  },
  skipBtn: {
    paddingHorizontal: 14, paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 20,
  },
  skipText: { fontSize: 13, color: 'rgba(255,255,255,0.5)' },

  content: {
    flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32,
  },

  circleOuter: {
    width: 260, height: 260, borderRadius: 130,
    borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', marginBottom: 44,
  },
  circleInner: {
    width: 200, height: 200, borderRadius: 100,
    alignItems: 'center', justifyContent: 'center',
  },
  emojiBox: {
    width: 130, height: 130, borderRadius: 36,
    borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
  },
  emoji: { fontSize: 64 },

  title: {
    fontSize: 30, fontWeight: '800', color: '#fff',
    textAlign: 'center', lineHeight: 38, marginBottom: 16,
  },
  sub: {
    fontSize: 15, color: 'rgba(255,255,255,0.5)',
    textAlign: 'center', lineHeight: 23,
  },

  dotsRow: {
    flexDirection: 'row', justifyContent: 'center',
    alignItems: 'center', gap: 8, marginBottom: 28,
  },
  dot: { height: 6, borderRadius: 3 },
  dotActive: { },
  dotInactive: { width: 6, backgroundColor: 'rgba(255,255,255,0.2)' },

  btnWrap: { paddingHorizontal: 24, paddingBottom: 32 },
  nextBtn: {
    borderRadius: 16, paddingVertical: 18, alignItems: 'center',
  },
  nextBtnText: { color: '#fff', fontSize: 16, fontWeight: '700', letterSpacing: 0.3 },
});

export default WelcomeScreen;
