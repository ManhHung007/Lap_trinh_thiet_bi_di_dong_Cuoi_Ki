import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Alert,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const ProfileScreen = ({ navigation }) => {
  const { user, logout } = useAuth();
  const { clearCart } = useCart();

  const handleLogout = () => {
    Alert.alert('Đăng xuất', 'Bạn có chắc muốn đăng xuất không?', [
      { text: 'Hủy', style: 'cancel' },
      { text: 'Đăng xuất', style: 'destructive', onPress: () => { clearCart(); logout(); } },
    ]);
  };

  const menuItems = [
    { icon: '📦', title: 'Đơn hàng của tôi',          sub: 'Theo dõi & quản lý đơn hàng',   screen: 'Orders' },
    { icon: '💳', title: 'Phương thức thanh toán',     sub: 'Thẻ tín dụng, ví điện tử',       screen: 'Payment' },
    { icon: '📍', title: 'Địa chỉ giao hàng',          sub: 'Quản lý địa chỉ nhận hàng',      screen: 'Address' },
    { icon: '🔔', title: 'Thông báo',                  sub: 'Cài đặt nhắc nhở, khuyến mãi',   screen: 'Notification' },
    { icon: '🔒', title: 'Bảo mật',                    sub: 'Đổi mật khẩu, xác thực 2 bước', screen: 'Security' },
    { icon: '❓', title: 'Hỗ trợ khách hàng',          sub: 'Trung tâm hỗ trợ, chat trực tiếp', screen: 'Support' },
    { icon: '⭐', title: 'Đánh giá ứng dụng',          sub: 'Chia sẻ cảm nhận của bạn',       screen: 'Rating' },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <ScrollView showsVerticalScrollIndicator={false}>

        <View style={styles.header}>
          <Text style={styles.title}>Tài khoản</Text>
        </View>

        {/* User card */}
        <View style={styles.userCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{user?.avatar || 'NA'}</Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{user?.name || 'Người dùng'}</Text>
            <Text style={styles.userEmail}>{user?.email || ''}</Text>
            {!!user?.phone && (
              <Text style={styles.userPhone}>📱 {user.phone}</Text>
            )}
            <View style={styles.vipBadge}>
              <Text style={styles.vipText}>⭐ VIP Member</Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.editBtn}
            onPress={() => navigation.navigate('EditProfile')}
          >
            <Text style={styles.editText}>✏️ Sửa</Text>
          </TouchableOpacity>
        </View>

        {/* Extra info row */}
        {(user?.gender || user?.birthday) && (
          <View style={styles.extraInfo}>
            {!!user?.gender && (
              <View style={styles.extraChip}>
                <Text style={styles.extraText}>
                  {user.gender === 'male' ? '👨 Nam' : user.gender === 'female' ? '👩 Nữ' : '🧑 Khác'}
                </Text>
              </View>
            )}
            {!!user?.birthday && (
              <View style={styles.extraChip}>
                <Text style={styles.extraText}>🎂 {user.birthday}</Text>
              </View>
            )}
          </View>
        )}

        {/* Stats */}
        <View style={styles.statsRow}>
          {[['12','Đơn hàng'],['5','Yêu thích'],['2.1M','Đã mua']].map(([num, label], i) => (
            <View key={i} style={[styles.statCard, i === 1 && styles.statDivider]}>
              <Text style={[styles.statNum, num.length > 3 && { fontSize: 16 }]}>{num}</Text>
              <Text style={styles.statLabel}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Voucher */}
        <TouchableOpacity style={styles.voucherBanner} activeOpacity={0.8}>
          <View>
            <Text style={styles.voucherTitle}>🎟️ Voucher của bạn</Text>
            <Text style={styles.voucherSub}>Bạn có 3 voucher chưa sử dụng</Text>
          </View>
          <Text style={styles.voucherArrow}>›</Text>
        </TouchableOpacity>

        {/* Menu */}
        <Text style={styles.menuSection}>Cài đặt</Text>
        {menuItems.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.menuItem}
            onPress={() => navigation.navigate(item.screen)}
            activeOpacity={0.75}
          >
            <View style={styles.menuIcon}>
              <Text style={styles.menuIconText}>{item.icon}</Text>
            </View>
            <View style={styles.menuTextWrap}>
              <Text style={styles.menuTitle}>{item.title}</Text>
              <Text style={styles.menuSub}>{item.sub}</Text>
            </View>
            <Text style={styles.menuArrow}>›</Text>
          </TouchableOpacity>
        ))}

        {/* Logout */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutIcon}>🚪</Text>
          <Text style={styles.logoutText}>Đăng xuất</Text>
        </TouchableOpacity>

        <Text style={styles.version}>TechShop v1.0.0</Text>
        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 },
  title: { fontSize: 24, fontWeight: '700', color: '#fff' },

  userCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    marginHorizontal: 20, marginBottom: 10,
    backgroundColor: '#12121a', borderRadius: 20,
    borderWidth: 1, borderColor: '#1e1e30', padding: 16,
  },
  avatar: { width: 64, height: 64, borderRadius: 20, backgroundColor: '#1a3a8f', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#2a5abf' },
  avatarText: { fontSize: 24, fontWeight: '800', color: '#fff' },
  userInfo: { flex: 1 },
  userName: { fontSize: 17, fontWeight: '700', color: '#fff', marginBottom: 2 },
  userEmail: { fontSize: 12, color: '#666', marginBottom: 3 },
  userPhone: { fontSize: 12, color: '#888', marginBottom: 5 },
  vipBadge: { backgroundColor: '#1a3a1a', alignSelf: 'flex-start', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  vipText: { fontSize: 10, color: '#4caf50', fontWeight: '600' },
  editBtn: { backgroundColor: '#1a3a8f', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: '#2a5abf' },
  editText: { fontSize: 12, color: '#4f8eff', fontWeight: '700' },

  extraInfo: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 14 },
  extraChip: { backgroundColor: '#12121a', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 6, borderWidth: 1, borderColor: '#1e1e30' },
  extraText: { fontSize: 12, color: '#888' },

  statsRow: { flexDirection: 'row', marginHorizontal: 20, marginBottom: 16, backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', overflow: 'hidden' },
  statCard: { flex: 1, alignItems: 'center', paddingVertical: 16 },
  statDivider: { borderLeftWidth: 1, borderRightWidth: 1, borderColor: '#1e1e30' },
  statNum: { fontSize: 22, fontWeight: '700', color: '#4f8eff', marginBottom: 2 },
  statLabel: { fontSize: 11, color: '#666' },

  voucherBanner: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, marginBottom: 24, backgroundColor: '#1a2a4a', borderRadius: 14, borderWidth: 1, borderColor: '#2a4a7a', padding: 14 },
  voucherTitle: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 2 },
  voucherSub: { fontSize: 12, color: '#6a9adf' },
  voucherArrow: { fontSize: 24, color: '#4f8eff', marginLeft: 'auto' },

  menuSection: { fontSize: 12, color: '#555', textTransform: 'uppercase', letterSpacing: 1, paddingHorizontal: 20, marginBottom: 10 },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 20, marginBottom: 8, backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', padding: 14 },
  menuIcon: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuIconText: { fontSize: 18 },
  menuTextWrap: { flex: 1 },
  menuTitle: { fontSize: 14, color: '#ddd', fontWeight: '500', marginBottom: 2 },
  menuSub: { fontSize: 11, color: '#555' },
  menuArrow: { fontSize: 20, color: '#333' },

  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginHorizontal: 20, marginTop: 16, backgroundColor: '#2a1a1a', borderRadius: 14, paddingVertical: 16, borderWidth: 1, borderColor: '#3a2020' },
  logoutIcon: { fontSize: 18 },
  logoutText: { fontSize: 15, fontWeight: '600', color: '#e94040' },
  version: { textAlign: 'center', fontSize: 12, color: '#333', marginTop: 16 },
});

export default ProfileScreen;
