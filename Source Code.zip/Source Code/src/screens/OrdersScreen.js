import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, SafeAreaView, StatusBar,
} from 'react-native';

const orders = [
  {
    id: 'TS240001', date: '15/04/2025', status: 'delivered',
    items: [{ name: 'iPhone 15 Pro Max', qty: 1, price: 31990000, emoji: '📱' }],
    total: 32040000,
  },
  {
    id: 'TS240002', date: '10/04/2025', status: 'shipping',
    items: [
      { name: 'Sony WH-1000XM5', qty: 1, price: 7490000, emoji: '🎧' },
      { name: 'MacBook Air M3', qty: 1, price: 27990000, emoji: '💻' },
    ],
    total: 35530000,
  },
  {
    id: 'TS240003', date: '02/04/2025', status: 'processing',
    items: [{ name: 'PS5 Slim', qty: 1, price: 13990000, emoji: '🎮' }],
    total: 14040000,
  },
  {
    id: 'TS240004', date: '20/03/2025', status: 'cancelled',
    items: [{ name: 'Galaxy Watch 6 Classic', qty: 1, price: 8990000, emoji: '⌚' }],
    total: 9040000,
  },
];

const statusConfig = {
  delivered: { label: 'Đã giao', color: '#22c55e', bg: '#0d2a0d' },
  shipping:  { label: 'Đang giao', color: '#4f8eff', bg: '#0d1b3e' },
  processing:{ label: 'Đang xử lý', color: '#f5a623', bg: '#2a1d0d' },
  cancelled: { label: 'Đã hủy', color: '#e94040', bg: '#2a0d0d' },
};

const tabs = ['Tất cả', 'Đang xử lý', 'Đang giao', 'Đã giao', 'Đã hủy'];
const tabStatus = { 'Đang xử lý': 'processing', 'Đang giao': 'shipping', 'Đã giao': 'delivered', 'Đã hủy': 'cancelled' };

const fmt = n => n.toLocaleString('vi-VN') + 'đ';

const OrdersScreen = ({ navigation }) => {
  const [tab, setTab] = useState('Tất cả');
  const filtered = tab === 'Tất cả' ? orders : orders.filter(o => o.status === tabStatus[tab]);

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Đơn hàng của tôi</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.tabs}>
        {tabs.map(t => (
          <TouchableOpacity key={t} style={[s.tab, tab === t && s.tabActive]} onPress={() => setTab(t)}>
            <Text style={[s.tabText, tab === t && s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 12 }}>
        {filtered.length === 0 && (
          <View style={s.empty}>
            <Text style={{ fontSize: 48 }}>📦</Text>
            <Text style={s.emptyText}>Không có đơn hàng</Text>
          </View>
        )}
        {filtered.map(order => {
          const st = statusConfig[order.status];
          return (
            <View key={order.id} style={s.card}>
              <View style={s.cardHeader}>
                <Text style={s.orderId}>#{order.id}</Text>
                <View style={[s.statusBadge, { backgroundColor: st.bg }]}>
                  <Text style={[s.statusText, { color: st.color }]}>{st.label}</Text>
                </View>
              </View>
              <Text style={s.date}>📅 {order.date}</Text>
              <View style={s.divider} />
              {order.items.map((item, i) => (
                <View key={i} style={s.itemRow}>
                  <Text style={s.itemEmoji}>{item.emoji}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={s.itemName} numberOfLines={1}>{item.name}</Text>
                    <Text style={s.itemQty}>x{item.qty}</Text>
                  </View>
                  <Text style={s.itemPrice}>{fmt(item.price)}</Text>
                </View>
              ))}
              <View style={s.divider} />
              <View style={s.totalRow}>
                <Text style={s.totalLabel}>Tổng tiền</Text>
                <Text style={s.totalValue}>{fmt(order.total)}</Text>
              </View>
              {order.status === 'delivered' && (
                <TouchableOpacity style={s.reviewBtn}>
                  <Text style={s.reviewBtnText}>⭐ Đánh giá sản phẩm</Text>
                </TouchableOpacity>
              )}
              {order.status === 'shipping' && (
                <TouchableOpacity style={s.trackBtn}>
                  <Text style={s.trackBtnText}>🗺 Theo dõi đơn hàng</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },
  tabs: { paddingHorizontal: 16, gap: 8, paddingBottom: 12 },
  tab: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: '#1a1a2e', borderWidth: 1, borderColor: '#2a2a45' },
  tabActive: { backgroundColor: '#1a3a8f', borderColor: '#4f8eff' },
  tabText: { fontSize: 13, color: '#888' },
  tabTextActive: { color: '#fff', fontWeight: '600' },
  card: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 14 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  orderId: { fontSize: 13, fontWeight: '700', color: '#fff' },
  statusBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  statusText: { fontSize: 12, fontWeight: '600' },
  date: { fontSize: 12, color: '#555', marginBottom: 10 },
  divider: { height: 1, backgroundColor: '#1e1e30', marginVertical: 10 },
  itemRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  itemEmoji: { fontSize: 24, width: 36, textAlign: 'center' },
  itemName: { fontSize: 13, color: '#ddd', fontWeight: '500' },
  itemQty: { fontSize: 12, color: '#555' },
  itemPrice: { fontSize: 13, fontWeight: '600', color: '#fff' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between' },
  totalLabel: { fontSize: 14, color: '#888' },
  totalValue: { fontSize: 16, fontWeight: '700', color: '#4f8eff' },
  reviewBtn: { marginTop: 12, backgroundColor: '#1a2a1a', borderRadius: 10, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: '#2a4a2a' },
  reviewBtnText: { color: '#22c55e', fontSize: 13, fontWeight: '600' },
  trackBtn: { marginTop: 12, backgroundColor: '#0d1b3e', borderRadius: 10, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: '#1a3a8f' },
  trackBtnText: { color: '#4f8eff', fontSize: 13, fontWeight: '600' },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, color: '#555' },
});

export default OrdersScreen;
