import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Alert, Image, ActivityIndicator,
} from 'react-native';
import { formatPrice, products, productImages } from '../data/products';
import { useCart } from '../context/CartContext';

const ProductDetailScreen = ({ route, navigation }) => {
  const { product } = route.params;
  const [qty, setQty] = useState(1);
  const [isFav, setIsFav] = useState(false);
  const [imgLoading, setImgLoading] = useState(true);
  const [imgError, setImgError] = useState(false);
  const { addItem } = useCart();

  const discount = Math.round((1 - product.price / product.oldPrice) * 100);

  const related = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addItem(product, qty);
    Alert.alert('✓ Thành công', `Đã thêm ${qty} sản phẩm vào giỏ hàng`, [
      { text: 'Tiếp tục mua', style: 'cancel' },
      { text: 'Xem giỏ hàng', onPress: () => navigation.navigate('Cart') },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
          <Text style={styles.iconBtnText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Chi tiết sản phẩm</Text>
        <TouchableOpacity style={styles.iconBtn} onPress={() => setIsFav(!isFav)}>
          <Text style={{ fontSize: 20 }}>{isFav ? '❤️' : '🤍'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Product image */}
        <View style={styles.imgBox}>
          {imgLoading && !imgError && (
            <ActivityIndicator style={styles.loader} color="#4f8eff" size="large" />
          )}
          {!imgError ? (
            <Image
              source={productImages[product.imageKey]}
              style={styles.img}
              resizeMode="cover"
              onLoad={() => setImgLoading(false)}
              onError={() => { setImgLoading(false); setImgError(true); }}
            />
          ) : (
            <View style={styles.imgFallback}>
              <Text style={{ fontSize: 80 }}>🖼️</Text>
            </View>
          )}
          {!!product.badge && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{product.badge}</Text>
            </View>
          )}
        </View>

        <View style={styles.content}>
          <Text style={styles.brand}>{product.brand}</Text>
          <Text style={styles.name}>{product.name}</Text>

          {/* Rating */}
          <View style={styles.ratingRow}>
            <Text style={styles.stars}>★★★★★</Text>
            <Text style={styles.ratingNum}>{product.rating}</Text>
            <Text style={styles.ratingCount}>({product.reviews.toLocaleString('vi-VN')} đánh giá)</Text>
          </View>

          {/* Price */}
          <View style={styles.priceRow}>
            <Text style={styles.price}>{formatPrice(product.price)}</Text>
            <Text style={styles.oldPrice}>{formatPrice(product.oldPrice)}</Text>
            <View style={styles.discountTag}>
              <Text style={styles.discountText}>-{discount}%</Text>
            </View>
          </View>

          {/* Specs */}
          <View style={styles.specGrid}>
            {Object.entries(product.specs).map(([key, val]) => (
              <View key={key} style={styles.specItem}>
                <Text style={styles.specLabel}>{key}</Text>
                <Text style={styles.specValue}>{val}</Text>
              </View>
            ))}
          </View>

          {/* Description */}
          <Text style={styles.descTitle}>Mô tả sản phẩm</Text>
          <Text style={styles.descText}>{product.desc}</Text>

          {/* Quantity */}
          <View style={styles.qtyRow}>
            <Text style={styles.qtyLabel}>Số lượng</Text>
            <View style={styles.qtyControls}>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => setQty(q => Math.max(1, q - 1))}>
                <Text style={styles.qtyBtnText}>−</Text>
              </TouchableOpacity>
              <Text style={styles.qtyNum}>{qty}</Text>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => setQty(q => q + 1)}>
                <Text style={styles.qtyBtnText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Total */}
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Thành tiền</Text>
            <Text style={styles.totalValue}>{formatPrice(product.price * qty)}</Text>
          </View>

          {/* Related products */}
          {related.length > 0 && (
            <>
              <Text style={styles.relatedTitle}>Sản phẩm liên quan</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.relatedScroll}>
                {related.map(p => (
                  <TouchableOpacity
                    key={p.id}
                    style={styles.relatedCard}
                    onPress={() => navigation.push('ProductDetail', { product: p })}
                    activeOpacity={0.85}
                  >
                    <Image
                      source={productImages[p.imageKey]}
                      style={styles.relatedImg}
                      resizeMode="cover"
                    />
                    <Text style={styles.relatedName} numberOfLines={2}>{p.name}</Text>
                    <Text style={styles.relatedPrice}>{formatPrice(p.price)}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </>
          )}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Bottom button */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.addCartBtn} onPress={handleAddToCart} activeOpacity={0.85}>
          <Text style={styles.addCartText}>🛒 Thêm vào giỏ hàng</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14 },
  iconBtn: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  iconBtnText: { color: '#fff', fontSize: 20 },
  headerTitle: { fontSize: 15, color: '#aaa' },
  imgBox: {
    height: 280, marginHorizontal: 20, borderRadius: 20,
    overflow: 'hidden', backgroundColor: '#1a1a2e',
    alignItems: 'center', justifyContent: 'center', position: 'relative',
  },
  img: { width: '100%', height: '100%' },
  loader: { position: 'absolute', zIndex: 1 },
  imgFallback: { width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute', top: 12, left: 12,
    backgroundColor: '#e94040', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 3, zIndex: 2,
  },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  content: { padding: 20 },
  brand: { fontSize: 12, color: '#4f8eff', textTransform: 'uppercase', letterSpacing: 1 },
  name: { fontSize: 22, fontWeight: '700', color: '#fff', marginVertical: 6, lineHeight: 30 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 16 },
  stars: { color: '#f5c518', fontSize: 14 },
  ratingNum: { fontSize: 14, color: '#fff', fontWeight: '600' },
  ratingCount: { fontSize: 12, color: '#666' },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 10, marginBottom: 20 },
  price: { fontSize: 26, fontWeight: '700', color: '#fff' },
  oldPrice: { fontSize: 15, color: '#555', textDecorationLine: 'line-through' },
  discountTag: { backgroundColor: '#1a3a1a', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  discountText: { color: '#4caf50', fontSize: 12, fontWeight: '600' },
  specGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  specItem: { backgroundColor: '#1a1a2e', borderRadius: 10, padding: 10, width: '47%' },
  specLabel: { fontSize: 10, color: '#666', marginBottom: 2 },
  specValue: { fontSize: 13, color: '#ccc', fontWeight: '500' },
  descTitle: { fontSize: 15, fontWeight: '600', color: '#fff', marginBottom: 8 },
  descText: { fontSize: 14, color: '#777', lineHeight: 22, marginBottom: 24 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  qtyLabel: { fontSize: 15, color: '#ccc' },
  qtyControls: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  qtyBtn: { width: 36, height: 36, backgroundColor: '#1a1a2e', borderRadius: 10, borderWidth: 1, borderColor: '#2a2a45', alignItems: 'center', justifyContent: 'center' },
  qtyBtnText: { color: '#fff', fontSize: 20, lineHeight: 22 },
  qtyNum: { fontSize: 18, fontWeight: '600', color: '#fff', minWidth: 24, textAlign: 'center' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#12121a', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#1e1e30' },
  totalLabel: { fontSize: 14, color: '#888' },
  totalValue: { fontSize: 20, fontWeight: '700', color: '#4f8eff' },
  relatedTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginTop: 24, marginBottom: 14 },
  relatedScroll: { marginHorizontal: -20, paddingHorizontal: 20 },
  relatedCard: { width: 140, marginRight: 12, backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', overflow: 'hidden' },
  relatedImg: { width: '100%', height: 100, backgroundColor: '#1a1a2e' },
  relatedName: { fontSize: 12, color: '#ddd', padding: 8, paddingBottom: 4, lineHeight: 16 },
  relatedPrice: { fontSize: 12, fontWeight: '700', color: '#4f8eff', paddingHorizontal: 8, paddingBottom: 10 },
  bottomBar: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, paddingBottom: 32, backgroundColor: '#0a0a0f', borderTopWidth: 1, borderTopColor: '#1a1a2e' },
  addCartBtn: { backgroundColor: '#4f8eff', borderRadius: 16, paddingVertical: 18, alignItems: 'center' },
  addCartText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});

export default ProductDetailScreen;
