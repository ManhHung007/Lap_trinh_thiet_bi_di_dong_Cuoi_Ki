import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  SafeAreaView, StatusBar, KeyboardAvoidingView,
  Platform, ScrollView, Alert,
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const RegisterScreen = ({ navigation }) => {
  const { register } = useAuth();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const set = (key, val) => {
    setForm(f => ({ ...f, [key]: val }));
    setErrors(e => ({ ...e, [key]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Vui lòng nhập họ tên';
    if (!form.email.trim()) e.email = 'Vui lòng nhập email';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Email không hợp lệ';
    if (!form.phone.trim()) e.phone = 'Vui lòng nhập số điện thoại';
    else if (!/^[0-9]{9,11}$/.test(form.phone.replace(/\s/g, '')))
      e.phone = 'Số điện thoại không hợp lệ';
    if (!form.password) e.password = 'Vui lòng nhập mật khẩu';
    else if (form.password.length < 6) e.password = 'Mật khẩu ít nhất 6 ký tự';
    if (!form.confirmPassword) e.confirmPassword = 'Vui lòng xác nhận mật khẩu';
    else if (form.password !== form.confirmPassword) e.confirmPassword = 'Mật khẩu không khớp';
    return e;
  };

  const handleRegister = async () => {
    const e = validate();
    if (Object.keys(e).length > 0) { setErrors(e); return; }
    setLoading(true);
    await new Promise(res => setTimeout(res, 1200));
    setLoading(false);

    // Tạo avatar từ 2 chữ cái đầu + cuối tên
    const words = form.name.trim().split(' ').filter(Boolean);
    const avatar = words.length >= 2
      ? (words[0][0] + words[words.length - 1][0]).toUpperCase()
      : words[0].slice(0, 2).toUpperCase();

    const result = register({
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      phone: form.phone.trim(),
      password: form.password,   // ← truyền đúng mật khẩu
      avatar,
    });

    if (result === 'duplicate') {
      setErrors({ email: 'Email này đã được đăng ký' });
      return;
    }

    Alert.alert(
      '🎉 Đăng ký thành công!',
      `Chào mừng ${form.name} đến với TechShop!\n\nEmail: ${form.email}\nMật khẩu: ${form.password}`,
      [{ text: 'Đăng nhập ngay', onPress: () => navigation.navigate('Login') }]
    );
  };

  const fields = [
    {
      key: 'name', label: 'Họ và tên', icon: '👤',
      placeholder: 'Nguyễn Văn A', keyboardType: 'default',
      autoCapitalize: 'words', secure: false,
    },
    {
      key: 'email', label: 'Email', icon: '✉️',
      placeholder: 'example@email.com', keyboardType: 'email-address',
      autoCapitalize: 'none', secure: false,
    },
    {
      key: 'phone', label: 'Số điện thoại', icon: '📱',
      placeholder: '0912 345 678', keyboardType: 'phone-pad',
      autoCapitalize: 'none', secure: false,
    },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backBtn}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.backText}>←</Text>
            </TouchableOpacity>
          </View>

          {/* Title */}
          <View style={styles.titleWrap}>
            <Text style={styles.title}>Tạo tài khoản</Text>
            <Text style={styles.subtitle}>Đăng ký để bắt đầu mua sắm 🛒</Text>
          </View>

          {/* Form */}
          <View style={styles.card}>
            {/* Các trường thông thường */}
            {fields.map(f => (
              <View key={f.key}>
                <Text style={styles.label}>{f.label}</Text>
                <View style={[styles.inputWrap, errors[f.key] && styles.inputError]}>
                  <Text style={styles.inputIcon}>{f.icon}</Text>
                  <TextInput
                    style={styles.input}
                    placeholder={f.placeholder}
                    placeholderTextColor="#444"
                    value={form[f.key]}
                    onChangeText={val => set(f.key, val)}
                    keyboardType={f.keyboardType}
                    autoCapitalize={f.autoCapitalize}
                    autoCorrect={false}
                  />
                </View>
                {!!errors[f.key] && (
                  <Text style={styles.errorText}>⚠ {errors[f.key]}</Text>
                )}
              </View>
            ))}

            {/* Mật khẩu */}
            <Text style={styles.label}>Mật khẩu</Text>
            <View style={[styles.inputWrap, errors.password && styles.inputError]}>
              <Text style={styles.inputIcon}>🔒</Text>
              <TextInput
                style={styles.input}
                placeholder="Tối thiểu 6 ký tự"
                placeholderTextColor="#444"
                value={form.password}
                onChangeText={val => set('password', val)}
                secureTextEntry={!showPass}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowPass(s => !s)} style={styles.eyeBtn}>
                <Text style={styles.eyeIcon}>{showPass ? '🙈' : '👁️'}</Text>
              </TouchableOpacity>
            </View>
            {!!errors.password && <Text style={styles.errorText}>⚠ {errors.password}</Text>}

            {/* Xác nhận mật khẩu */}
            <Text style={styles.label}>Xác nhận mật khẩu</Text>
            <View style={[styles.inputWrap, errors.confirmPassword && styles.inputError]}>
              <Text style={styles.inputIcon}>🔐</Text>
              <TextInput
                style={styles.input}
                placeholder="Nhập lại mật khẩu"
                placeholderTextColor="#444"
                value={form.confirmPassword}
                onChangeText={val => set('confirmPassword', val)}
                secureTextEntry={!showConfirm}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowConfirm(s => !s)} style={styles.eyeBtn}>
                <Text style={styles.eyeIcon}>{showConfirm ? '🙈' : '👁️'}</Text>
              </TouchableOpacity>
            </View>
            {!!errors.confirmPassword && (
              <Text style={styles.errorText}>⚠ {errors.confirmPassword}</Text>
            )}

            {/* Password strength */}
            {form.password.length > 0 && (
              <View style={styles.strengthRow}>
                {[1, 2, 3, 4].map(i => (
                  <View
                    key={i}
                    style={[
                      styles.strengthBar,
                      form.password.length >= i * 2 && (
                        form.password.length >= 8 ? styles.strengthStrong :
                        form.password.length >= 6 ? styles.strengthMed :
                        styles.strengthWeak
                      ),
                    ]}
                  />
                ))}
                <Text style={styles.strengthText}>
                  {form.password.length < 6 ? 'Yếu' :
                   form.password.length < 8 ? 'Trung bình' : 'Mạnh'}
                </Text>
              </View>
            )}

            {/* Điều khoản */}
            <View style={styles.termsRow}>
              <Text style={styles.termsText}>
                Bằng cách đăng ký, bạn đồng ý với{' '}
                <Text style={styles.termsLink}>Điều khoản dịch vụ</Text>
                {' '}và{' '}
                <Text style={styles.termsLink}>Chính sách bảo mật</Text>
              </Text>
            </View>

            {/* Submit */}
            <TouchableOpacity
              style={[styles.registerBtn, loading && styles.registerBtnLoading]}
              onPress={handleRegister}
              disabled={loading}
              activeOpacity={0.85}
            >
              <Text style={styles.registerBtnText}>
                {loading ? 'Đang tạo tài khoản...' : 'Đăng ký'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Login link */}
          <View style={styles.loginRow}>
            <Text style={styles.loginText}>Đã có tài khoản? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginLink}>Đăng nhập</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  container: { flexGrow: 1, padding: 24 },
  header: { marginBottom: 8 },
  backBtn: {
    width: 40, height: 40, backgroundColor: '#1a1a2e',
    borderRadius: 12, alignItems: 'center', justifyContent: 'center',
  },
  backText: { color: '#fff', fontSize: 20 },
  titleWrap: { marginBottom: 24 },
  title: { fontSize: 28, fontWeight: '800', color: '#fff', marginBottom: 6 },
  subtitle: { fontSize: 14, color: '#666' },
  card: {
    backgroundColor: '#12121a', borderRadius: 24,
    borderWidth: 1, borderColor: '#1e1e30',
    padding: 20, marginBottom: 24,
  },
  label: { fontSize: 13, fontWeight: '600', color: '#aaa', marginBottom: 8, marginTop: 4 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#1a1a2e', borderRadius: 14,
    borderWidth: 1, borderColor: '#2a2a45',
    paddingHorizontal: 14, marginBottom: 4, gap: 10,
  },
  inputError: { borderColor: '#e94040' },
  inputIcon: { fontSize: 16 },
  input: { flex: 1, color: '#fff', fontSize: 15, paddingVertical: 14 },
  eyeBtn: { padding: 4 },
  eyeIcon: { fontSize: 16 },
  errorText: { fontSize: 12, color: '#e94040', marginBottom: 10, marginLeft: 4 },
  strengthRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12, marginTop: 4,
  },
  strengthBar: {
    flex: 1, height: 4, borderRadius: 2, backgroundColor: '#2a2a45',
  },
  strengthWeak: { backgroundColor: '#e94040' },
  strengthMed: { backgroundColor: '#f5a623' },
  strengthStrong: { backgroundColor: '#4caf50' },
  strengthText: { fontSize: 11, color: '#888', minWidth: 60 },
  termsRow: { marginVertical: 16 },
  termsText: { fontSize: 12, color: '#555', lineHeight: 18 },
  termsLink: { color: '#4f8eff' },
  registerBtn: {
    backgroundColor: '#4f8eff', borderRadius: 14,
    paddingVertical: 16, alignItems: 'center', marginTop: 4,
  },
  registerBtnLoading: { backgroundColor: '#1a2a4a' },
  registerBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  loginRow: {
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center',
  },
  loginText: { fontSize: 14, color: '#555' },
  loginLink: { fontSize: 14, color: '#4f8eff', fontWeight: '600' },
});

export default RegisterScreen;
