import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, StatusBar } from 'react-native';

const SplashScreen = ({ onDone }) => {
  const scale = useRef(new Animated.Value(0.4)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const fadeOut = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale, { toValue: 1, tension: 55, friction: 6, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 500, useNativeDriver: true }),
      ]),
      Animated.delay(800),
      Animated.timing(fadeOut, { toValue: 0, duration: 400, useNativeDriver: true }),
    ]).start(() => onDone());
  }, []);

  return (
    <Animated.View style={[styles.container, { opacity: fadeOut }]}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={styles.glow} />
      <Animated.View style={{ opacity, transform: [{ scale }], alignItems: 'center' }}>
        <View style={styles.logo}>
          <Text style={styles.logoIcon}>⚡</Text>
        </View>
        <Text style={styles.appName}>TechShop</Text>
      </Animated.View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: '#0a0a0f',
    alignItems: 'center', justifyContent: 'center',
  },
  glow: {
    position: 'absolute', width: 260, height: 260, borderRadius: 130,
    backgroundColor: '#1a3a8f', opacity: 0.18,
  },
  logo: {
    width: 90, height: 90, borderRadius: 26,
    backgroundColor: '#1a3a8f', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: '#2a5abf', marginBottom: 16,
  },
  logoIcon: { fontSize: 44 },
  appName: { fontSize: 34, fontWeight: '800', color: '#fff', letterSpacing: 2 },
});

export default SplashScreen;
