import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Alert, Modal, TextInput,
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const AddressScreen = ({ navigation }) => {
  const { user } = useAuth();

  const makeDefaultAddresses = (u) => [
    {
      id: 1,
      name: u?.name || 'Người dùng',
      phone: u?.phone || '',
      address: '123 Đường Láng',
      ward: 'Phường Láng Thượng',
      district: 'Quận Đống Đa',
      city: 'Hà Nội',
      type: 'home',
      default: true,
    },
    {
      id: 2,
      name: u?.name || 'Người dùng',
      phone: u?.phone || '',
      address: '45 Nguyễn Trãi',
      ward: 'Phường Thượng Đình',
      district: 'Quận Thanh Xuân',
      city: 'Hà Nội',
      type: 'work',
      default: false,
    },
  ];

  const [addresses, setAddresses] = useState(() => makeDefaultAddresses(user));

  // Khi user đổi tên/SĐT (qua EditProfile), cập nhật địa chỉ theo
  useEffect(() => {
    setAddresses(prev => prev.map(addr => ({
      ...addr,
      name: user?.name || addr.name,
      phone: user?.phone || addr.phone,
    })));
  }, [user?.name, user?.phone]);

  const [showModal, setShowModal] = useState(false);
  const [editingAddr, setEditingAddr] = useState(null); // null = thêm mới
  const [form, setForm] = useState({
    name: '', phone: '', address: '', ward: '', district: '', city: 'Hà Nội', type: 'home',
  });
  const [formErrors, setFormErrors] = useState({});

  const setDefault = (id) =>
    setAddresses(prev => prev.map(a => ({ ...a, default: a.id === id })));

  const deleteAddr = (id) => {
    Alert.alert('Xóa địa chỉ?', 'Bạn có chắc muốn xóa địa chỉ này?', [
      { text: 'Hủy', style: 'cancel' },
      { text: 'Xóa', style: 'destructive', onPress: () => setAddresses(prev => prev.filter(a => a.id !== id)) },
    ]);
  };

  const openAdd = () => {
    setEditingAddr(null);
    setForm({ name: user?.name || '', phone: user?.phone || '', address: '', ward: '', district: '', city: 'Hà Nội', type: 'home' });
    setFormErrors({});
    setShowModal(true);
  };

  const openEdit = (addr) => {
    setEditingAddr(addr.id);
    setForm({ name: addr.name, phone: addr.phone, address: addr.address, ward: addr.ward, district: addr.district, city: addr.city, type: addr.type });
    setFormErrors({});
    setShowModal(true);
  };

  const validateForm = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Vui lòng nhập họ tên';
    if (!form.phone.trim()) e.phone = 'Vui lòng nhập số điện thoại';
    if (!form.address.trim()) e.address = 'Vui lòng nhập địa chỉ';
    if (!form.district.trim()) e.district = 'Vui lòng nhập quận/huyện';
    return e;
  };

  const handleSave = () => {
    const e = validateForm();
    if (Object.keys(e).length > 0) { setFormErrors(e); return; }

    if (editingAddr) {
      setAddresses(prev => prev.map(a => a.id === editingAddr ? { ...a, ...form } : a));
    } else {
      const newId = Date.now();
      setAddresses(prev => [...prev, { id: newId, ...form, default: prev.length === 0 }]);
    }
    setShowModal(false);
  };

  const typeLabels = { home: '🏠 Nhà', work: '🏢 Công ty', other: '📍 Khác' };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Địa chỉ giao hàng</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 12 }}>
        {addresses.length === 0 && (
          <View style={s.empty}>
            <Text style={{ fontSize: 48 }}>📍</Text>
            <Text style={s.emptyText}>Chưa có địa chỉ nào</Text>
          </View>
        )}

        {addresses.map(addr => (
          <View key={addr.id} style={s.card}>
            <View style={s.cardTop}>
              <View style={s.typeChip}>
                <Text style={s.typeText}>{typeLabels[addr.type] || '📍 Khác'}</Text>
              </View>
              {addr.default && (
                <View style={s.defaultChip}>
                  <Text style={s.defaultText}>✓ Mặc định</Text>
                </View>
              )}
            </View>

            <Text style={s.name}>{addr.name}</Text>
            {!!addr.phone && <Text style={s.phone}>📞 {addr.phone}</Text>}
            <Text style={s.addrText}>
              📍 {addr.address}, {addr.ward}, {addr.district}, {addr.city}
            </Text>

            <View style={s.divider} />
            <View style={s.actions}>
              <TouchableOpacity style={s.editBtn} onPress={() => openEdit(addr)}>
                <Text style={s.editText}>✏️ Sửa</Text>
              </TouchableOpacity>
              {!addr.default && (
                <TouchableOpacity style={s.defaultBtn} onPress={() => setDefault(addr.id)}>
                  <Text style={s.defaultBtnText}>Đặt mặc định</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={s.delBtn} onPress={() => deleteAddr(addr.id)}>
                <Text style={{ fontSize: 18 }}>🗑</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <TouchableOpacity style={s.addBtn} onPress={openAdd}>
          <Text style={s.addIcon}>+</Text>
          <Text style={s.addText}>Thêm địa chỉ mới</Text>
        </TouchableOpacity>
        <View style={{ height: 20 }} />
      </ScrollView>

      {/* Modal thêm/sửa địa chỉ */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modal}>
            <View style={s.modalHandle} />
            <Text style={s.modalTitle}>{editingAddr ? 'Sửa địa chỉ' : 'Thêm địa chỉ mới'}</Text>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Loại địa chỉ */}
              <Text style={s.label}>Loại địa chỉ</Text>
              <View style={s.typeRow}>
                {Object.entries(typeLabels).map(([key, label]) => (
                  <TouchableOpacity
                    key={key}
                    style={[s.typeBtn, form.type === key && s.typeBtnActive]}
                    onPress={() => setForm(f => ({ ...f, type: key }))}
                  >
                    <Text style={[s.typeBtnText, form.type === key && s.typeBtnTextActive]}>{label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {[
                { key: 'name', label: 'Họ và tên *', icon: '👤', placeholder: 'Nguyễn Văn A' },
                { key: 'phone', label: 'Số điện thoại *', icon: '📞', placeholder: '0912 345 678', keyboard: 'phone-pad' },
                { key: 'address', label: 'Số nhà, tên đường *', icon: '🏠', placeholder: '123 Đường Láng' },
                { key: 'ward', label: 'Phường/Xã', icon: '📌', placeholder: 'Phường Láng Thượng' },
                { key: 'district', label: 'Quận/Huyện *', icon: '🗺', placeholder: 'Quận Đống Đa' },
                { key: 'city', label: 'Tỉnh/Thành phố', icon: '🏙', placeholder: 'Hà Nội' },
              ].map(f => (
                <View key={f.key}>
                  <Text style={s.label}>{f.label}</Text>
                  <View style={[s.inputWrap, formErrors[f.key] && s.inputError]}>
                    <Text style={s.inputIcon}>{f.icon}</Text>
                    <TextInput
                      style={s.input}
                      value={form[f.key]}
                      onChangeText={v => { setForm(prev => ({ ...prev, [f.key]: v })); setFormErrors(e => ({ ...e, [f.key]: '' })); }}
                      placeholder={f.placeholder}
                      placeholderTextColor="#444"
                      keyboardType={f.keyboard || 'default'}
                    />
                  </View>
                  {!!formErrors[f.key] && <Text style={s.errorText}>⚠ {formErrors[f.key]}</Text>}
                </View>
              ))}
            </ScrollView>

            <View style={s.modalBtns}>
              <TouchableOpacity style={s.cancelBtn} onPress={() => setShowModal(false)}>
                <Text style={s.cancelText}>Hủy</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.saveBtn} onPress={handleSave}>
                <Text style={s.saveBtnText}>{editingAddr ? 'Cập nhật' : 'Thêm mới'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },

  card: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 16 },
  cardTop: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  typeChip: { backgroundColor: '#1a1a2e', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  typeText: { fontSize: 12, color: '#aaa' },
  defaultChip: { backgroundColor: '#0d2a0d', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  defaultText: { fontSize: 12, color: '#22c55e', fontWeight: '600' },
  name: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 4 },
  phone: { fontSize: 13, color: '#aaa', marginBottom: 6 },
  addrText: { fontSize: 13, color: '#777', lineHeight: 20 },
  divider: { height: 1, backgroundColor: '#1e1e30', marginVertical: 12 },
  actions: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  editBtn: { backgroundColor: '#1a1a2e', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: '#2a2a45' },
  editText: { color: '#aaa', fontSize: 13 },
  defaultBtn: { flex: 1, backgroundColor: '#0d1b3e', borderRadius: 10, paddingVertical: 8, alignItems: 'center', borderWidth: 1, borderColor: '#1a3a8f' },
  defaultBtnText: { color: '#4f8eff', fontSize: 13, fontWeight: '600' },
  delBtn: { width: 38, height: 38, backgroundColor: '#2a1a1a', borderRadius: 10, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#3a2020' },

  addBtn: { borderWidth: 1.5, borderColor: '#2a2a45', borderStyle: 'dashed', borderRadius: 16, padding: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  addIcon: { fontSize: 24, color: '#4f8eff' },
  addText: { color: '#4f8eff', fontSize: 15, fontWeight: '600' },

  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, color: '#555' },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#12121a', borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, borderWidth: 1, borderColor: '#1e1e30', maxHeight: '90%' },
  modalHandle: { width: 40, height: 4, backgroundColor: '#2a2a45', borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 16 },

  label: { fontSize: 13, fontWeight: '600', color: '#aaa', marginBottom: 8, marginTop: 4 },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  typeBtn: { flex: 1, backgroundColor: '#1a1a2e', borderRadius: 10, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: '#2a2a45' },
  typeBtnActive: { backgroundColor: '#0d1b3e', borderColor: '#4f8eff' },
  typeBtnText: { fontSize: 12, color: '#888' },
  typeBtnTextActive: { color: '#4f8eff', fontWeight: '700' },

  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#0e0e18', borderRadius: 12, borderWidth: 1, borderColor: '#1e1e30', paddingHorizontal: 12, marginBottom: 4, gap: 8 },
  inputError: { borderColor: '#e94040' },
  inputIcon: { fontSize: 16 },
  input: { flex: 1, color: '#fff', fontSize: 14, paddingVertical: 12 },
  errorText: { fontSize: 12, color: '#e94040', marginBottom: 8, marginLeft: 4 },

  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 16, paddingBottom: 16 },
  cancelBtn: { flex: 1, backgroundColor: '#1a1a2e', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  cancelText: { color: '#888', fontSize: 15, fontWeight: '600' },
  saveBtn: { flex: 2, backgroundColor: '#4f8eff', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});

export default AddressScreen;
