import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Alert, TextInput, Linking,
} from 'react-native';

const faqs = [
  { q: 'Làm thế nào để đổi/trả hàng?', a: 'Bạn có thể yêu cầu đổi trả trong vòng 7 ngày kể từ ngày nhận hàng. Sản phẩm phải còn nguyên vẹn, chưa qua sử dụng và còn đầy đủ hộp, phụ kiện.' },
  { q: 'Thời gian giao hàng là bao lâu?', a: 'Giao hàng nội thành Hà Nội và TP.HCM: 1-2 ngày. Các tỉnh thành khác: 2-5 ngày làm việc.' },
  { q: 'Tôi có thể theo dõi đơn hàng ở đâu?', a: 'Bạn có thể theo dõi đơn hàng trong mục "Đơn hàng của tôi" ở trang Tài khoản.' },
  { q: 'Sản phẩm có bảo hành không?', a: 'Tất cả sản phẩm tại TechShop đều có bảo hành chính hãng từ 12-24 tháng tùy theo nhà sản xuất.' },
];

export const SupportScreen = ({ navigation }) => {
  const [expanded, setExpanded] = useState(null);
  const [message, setMessage] = useState('');

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Hỗ trợ khách hàng</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 20 }}>
        {/* Liên hệ nhanh */}
        <Text style={s.sectionTitle}>Liên hệ trực tiếp</Text>
        <View style={s.contactRow}>
          {[
            { icon: '📞', label: 'Hotline', value: '1800 1234', onPress: () => Linking.openURL('tel:18001234') },
            { icon: '💬', label: 'Live Chat', value: 'Chat ngay', onPress: () => Alert.alert('Chat', 'Đang mở chat...') },
            { icon: '📧', label: 'Email', value: 'support@techshop.vn', onPress: () => Linking.openURL('mailto:support@techshop.vn') },
          ].map((c, i) => (
            <TouchableOpacity key={i} style={s.contactCard} onPress={c.onPress}>
              <Text style={s.contactIcon}>{c.icon}</Text>
              <Text style={s.contactLabel}>{c.label}</Text>
              <Text style={s.contactValue} numberOfLines={1}>{c.value}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Gửi tin nhắn */}
        <Text style={s.sectionTitle}>Gửi yêu cầu hỗ trợ</Text>
        <View style={s.card}>
          <TextInput
            style={s.msgInput}
            placeholder="Mô tả vấn đề của bạn..."
            placeholderTextColor="#444"
            multiline
            numberOfLines={4}
            value={message}
            onChangeText={setMessage}
            textAlignVertical="top"
          />
          <TouchableOpacity
            style={[s.sendBtn, !message && s.sendBtnDisabled]}
            onPress={() => { Alert.alert('✅ Đã gửi', 'Chúng tôi sẽ phản hồi trong vòng 24 giờ'); setMessage(''); }}
            disabled={!message}
          >
            <Text style={s.sendText}>Gửi yêu cầu →</Text>
          </TouchableOpacity>
        </View>

        {/* FAQ */}
        <Text style={s.sectionTitle}>Câu hỏi thường gặp</Text>
        {faqs.map((faq, i) => (
          <TouchableOpacity key={i} style={s.faqItem} onPress={() => setExpanded(expanded === i ? null : i)}>
            <View style={s.faqQ}>
              <Text style={s.faqQText} numberOfLines={expanded === i ? undefined : 1}>{faq.q}</Text>
              <Text style={s.faqArrow}>{expanded === i ? '▲' : '▼'}</Text>
            </View>
            {expanded === i && <Text style={s.faqA}>{faq.a}</Text>}
          </TouchableOpacity>
        ))}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

export const RatingScreen = ({ navigation }) => {
  const [stars, setStars] = useState(0);
  const [review, setReview] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const labels = ['', 'Rất tệ 😞', 'Chưa tốt 😐', 'Bình thường 🙂', 'Tốt 😊', 'Tuyệt vời! 🤩'];
  const features = ['Giao diện đẹp', 'Dễ sử dụng', 'Tốc độ nhanh', 'Nhiều sản phẩm', 'Giá tốt'];
  const [selectedFeatures, setSelectedFeatures] = useState([]);

  const toggleFeature = (f) => setSelectedFeatures(prev =>
    prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]
  );

  const submit = () => {
    if (!stars) { Alert.alert('Vui lòng chọn số sao'); return; }
    setSubmitted(true);
  };

  if (submitted) return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Đánh giá</Text>
        <View style={{ width: 38 }} />
      </View>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16, padding: 32 }}>
        <Text style={{ fontSize: 80 }}>🎉</Text>
        <Text style={{ fontSize: 22, fontWeight: '800', color: '#fff', textAlign: 'center' }}>Cảm ơn bạn!</Text>
        <Text style={{ fontSize: 14, color: '#666', textAlign: 'center', lineHeight: 22 }}>
          Đánh giá của bạn giúp chúng tôi cải thiện ứng dụng tốt hơn mỗi ngày.
        </Text>
        <TouchableOpacity style={[s.sendBtn, { marginTop: 16 }]} onPress={() => navigation.goBack()}>
          <Text style={s.sendText}>Quay về trang chủ</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Đánh giá ứng dụng</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 20 }}>
        {/* Stars */}
        <View style={s.starsCard}>
          <Text style={s.starsTitle}>Bạn thấy TechShop thế nào?</Text>
          <View style={s.starsRow}>
            {[1,2,3,4,5].map(i => (
              <TouchableOpacity key={i} onPress={() => setStars(i)}>
                <Text style={[s.star, i <= stars && s.starActive]}>{i <= stars ? '★' : '☆'}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {stars > 0 && <Text style={s.starLabel}>{labels[stars]}</Text>}
        </View>

        {/* Tính năng */}
        <Text style={s.sectionTitle}>Bạn thích điều gì nhất?</Text>
        <View style={s.featuresWrap}>
          {features.map(f => (
            <TouchableOpacity
              key={f}
              style={[s.featureChip, selectedFeatures.includes(f) && s.featureChipActive]}
              onPress={() => toggleFeature(f)}
            >
              <Text style={[s.featureText, selectedFeatures.includes(f) && s.featureTextActive]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Nhận xét */}
        <Text style={s.sectionTitle}>Nhận xét của bạn</Text>
        <View style={s.card}>
          <TextInput
            style={s.msgInput}
            placeholder="Chia sẻ cảm nhận của bạn về TechShop..."
            placeholderTextColor="#444"
            multiline
            numberOfLines={4}
            value={review}
            onChangeText={setReview}
            textAlignVertical="top"
          />
        </View>

        <TouchableOpacity style={[s.sendBtn, !stars && s.sendBtnDisabled]} onPress={submit} disabled={!stars}>
          <Text style={s.sendText}>⭐ Gửi đánh giá</Text>
        </TouchableOpacity>
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },
  sectionTitle: { fontSize: 12, color: '#555', textTransform: 'uppercase', letterSpacing: 1 },
  card: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 14 },
  contactRow: { flexDirection: 'row', gap: 10 },
  contactCard: { flex: 1, backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', padding: 14, alignItems: 'center', gap: 6 },
  contactIcon: { fontSize: 26 },
  contactLabel: { fontSize: 11, color: '#666' },
  contactValue: { fontSize: 11, color: '#4f8eff', fontWeight: '600', textAlign: 'center' },
  msgInput: { color: '#fff', fontSize: 14, minHeight: 100, marginBottom: 12, lineHeight: 22 },
  sendBtn: { backgroundColor: '#4f8eff', borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  sendBtnDisabled: { backgroundColor: '#1a2a4a' },
  sendText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  faqItem: { backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', padding: 14 },
  faqQ: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  faqQText: { flex: 1, fontSize: 14, color: '#ddd', fontWeight: '500' },
  faqArrow: { fontSize: 10, color: '#555' },
  faqA: { fontSize: 13, color: '#888', marginTop: 10, lineHeight: 20 },
  starsCard: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 20, alignItems: 'center', gap: 16 },
  starsTitle: { fontSize: 16, fontWeight: '600', color: '#fff' },
  starsRow: { flexDirection: 'row', gap: 12 },
  star: { fontSize: 40, color: '#333' },
  starActive: { color: '#f5c518' },
  starLabel: { fontSize: 15, color: '#f5c518', fontWeight: '600' },
  featuresWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  featureChip: { backgroundColor: '#1a1a2e', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, borderWidth: 1, borderColor: '#2a2a45' },
  featureChipActive: { backgroundColor: '#1a3a8f', borderColor: '#4f8eff' },
  featureText: { fontSize: 13, color: '#888' },
  featureTextActive: { color: '#fff', fontWeight: '600' },
});
