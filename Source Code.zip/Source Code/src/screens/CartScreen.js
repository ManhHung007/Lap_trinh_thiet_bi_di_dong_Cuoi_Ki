import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Alert, Image, Modal, Animated,
} from 'react-native';
import { formatPrice, productImages } from '../data/products';
import { useCart } from '../context/CartContext';

const PAYMENT_METHODS = [
  { id: 'cod',     icon: '💵', name: 'Tiền mặt (COD)',       sub: 'Thanh toán khi nhận hàng' },
  { id: 'momo',    icon: '💜', name: 'Ví MoMo',               sub: 'Thanh toán qua ví MoMo' },
  { id: 'zalopay', icon: '💙', name: 'ZaloPay',               sub: 'Thanh toán qua ZaloPay' },
  { id: 'visa',    icon: '💳', name: 'Thẻ Visa / MasterCard', sub: '•••• •••• •••• 4242' },
  { id: 'banking', icon: '🏦', name: 'Chuyển khoản ngân hàng',sub: 'VCB / TCB / MB Bank' },
];

const SHIPPING = 50000;

// ── Màn hình thành công ────────────────────────────────────────
const SuccessScreen = ({ total, method, onDone }) => {
  const pm = PAYMENT_METHODS.find(p => p.id === method);
  return (
    <View style={ss.overlay}>
      <View style={ss.card}>
        {/* Circle check */}
        <View style={ss.circle}>
          <Text style={ss.check}>✓</Text>
        </View>
        <Text style={ss.title}>Đặt hàng thành công!</Text>
        <Text style={ss.sub}>Cảm ơn bạn đã mua sắm tại TechShop 🎉</Text>

        {/* Order info */}
        <View style={ss.infoBox}>
          <View style={ss.infoRow}>
            <Text style={ss.infoLabel}>Mã đơn hàng</Text>
            <Text style={ss.infoValue}>#TS{Math.floor(Math.random()*90000+10000)}</Text>
          </View>
          <View style={ss.infoRow}>
            <Text style={ss.infoLabel}>Phương thức</Text>
            <Text style={ss.infoValue}>{pm?.icon} {pm?.name}</Text>
          </View>
          <View style={ss.infoRow}>
            <Text style={ss.infoLabel}>Tổng thanh toán</Text>
            <Text style={[ss.infoValue, { color: '#4f8eff', fontWeight: '700' }]}>{formatPrice(total)}</Text>
          </View>
          <View style={ss.infoRow}>
            <Text style={ss.infoLabel}>Dự kiến giao hàng</Text>
            <Text style={ss.infoValue}>2 – 3 ngày làm việc</Text>
          </View>
        </View>

        <TouchableOpacity style={ss.btn} onPress={onDone}>
          <Text style={ss.btnText}>Về trang chủ</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const ss = StyleSheet.create({
  overlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.85)', alignItems: 'center', justifyContent: 'center', zIndex: 999, padding: 24 },
  card: { backgroundColor: '#12121a', borderRadius: 28, borderWidth: 1, borderColor: '#1e1e30', padding: 28, width: '100%', alignItems: 'center' },
  circle: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#0d2a0d', borderWidth: 2, borderColor: '#22c55e', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  check: { fontSize: 36, color: '#22c55e', fontWeight: '700' },
  title: { fontSize: 22, fontWeight: '800', color: '#fff', marginBottom: 8 },
  sub: { fontSize: 14, color: '#666', marginBottom: 20, textAlign: 'center' },
  infoBox: { backgroundColor: '#0e0e18', borderRadius: 16, padding: 16, width: '100%', marginBottom: 24, gap: 12 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  infoLabel: { fontSize: 13, color: '#666' },
  infoValue: { fontSize: 13, color: '#ccc', fontWeight: '500' },
  btn: { backgroundColor: '#4f8eff', borderRadius: 14, paddingVertical: 14, paddingHorizontal: 40 },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});

// ── Modal chọn phương thức thanh toán ─────────────────────────
const PaymentModal = ({ visible, selected, onSelect, onClose, onConfirm, total }) => (
  <Modal visible={visible} transparent animationType="slide">
    <View style={pm.overlay}>
      <View style={pm.sheet}>
        <View style={pm.handle} />
        <Text style={pm.title}>Chọn phương thức thanh toán</Text>

        {PAYMENT_METHODS.map(method => (
          <TouchableOpacity
            key={method.id}
            style={[pm.methodRow, selected === method.id && pm.methodRowActive]}
            onPress={() => onSelect(method.id)}
            activeOpacity={0.8}
          >
            <View style={pm.methodIcon}>
              <Text style={{ fontSize: 22 }}>{method.icon}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={pm.methodName}>{method.name}</Text>
              <Text style={pm.methodSub}>{method.sub}</Text>
            </View>
            <View style={[pm.radio, selected === method.id && pm.radioActive]}>
              {selected === method.id && <View style={pm.radioDot} />}
            </View>
          </TouchableOpacity>
        ))}

        <View style={pm.totalRow}>
          <Text style={pm.totalLabel}>Tổng thanh toán</Text>
          <Text style={pm.totalValue}>{formatPrice(total)}</Text>
        </View>

        <TouchableOpacity
          style={[pm.confirmBtn, !selected && pm.confirmBtnDisabled]}
          onPress={onConfirm}
          disabled={!selected}
        >
          <Text style={pm.confirmText}>Xác nhận đặt hàng →</Text>
        </TouchableOpacity>

        <TouchableOpacity style={pm.cancelBtn} onPress={onClose}>
          <Text style={pm.cancelText}>Hủy</Text>
        </TouchableOpacity>
      </View>
    </View>
  </Modal>
);

const pm = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#12121a', borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, borderWidth: 1, borderColor: '#1e1e30', paddingBottom: 40 },
  handle: { width: 40, height: 4, backgroundColor: '#2a2a45', borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  title: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 16 },
  methodRow: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', marginBottom: 10, gap: 12, backgroundColor: '#0e0e18' },
  methodRowActive: { borderColor: '#4f8eff', backgroundColor: '#0d1b3e' },
  methodIcon: { width: 44, height: 44, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  methodName: { fontSize: 14, color: '#ddd', fontWeight: '600', marginBottom: 2 },
  methodSub: { fontSize: 12, color: '#555' },
  radio: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: '#333', alignItems: 'center', justifyContent: 'center' },
  radioActive: { borderColor: '#4f8eff' },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#4f8eff' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#0a0a14', borderRadius: 12, padding: 14, marginVertical: 14 },
  totalLabel: { fontSize: 15, color: '#888' },
  totalValue: { fontSize: 18, fontWeight: '700', color: '#4f8eff' },
  confirmBtn: { backgroundColor: '#4f8eff', borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginBottom: 10 },
  confirmBtnDisabled: { backgroundColor: '#1a2a4a' },
  confirmText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  cancelBtn: { paddingVertical: 12, alignItems: 'center' },
  cancelText: { color: '#555', fontSize: 14 },
});

// ── Main CartScreen ────────────────────────────────────────────
const CartScreen = ({ navigation }) => {
  const { items, removeItem, updateQty, clearCart, subtotal } = useCart();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState('cod');
  const [showSuccess, setShowSuccess] = useState(false);
  const [lastTotal, setLastTotal] = useState(0);
  const [lastPayment, setLastPayment] = useState('cod');

  const discount = Math.round(subtotal * 0.05);
  const total = subtotal + SHIPPING - discount;

  const handleCheckout = () => {
    setShowPaymentModal(true);
  };

  const handleConfirmPayment = () => {
    setShowPaymentModal(false);
    setLastTotal(total);
    setLastPayment(selectedPayment);
    setShowSuccess(true);
  };

  const handleSuccessDone = () => {
    setShowSuccess(false);
    clearCart();
    navigation.navigate('HomeTab');
  };

  const handleClearAll = () => {
    Alert.alert('Xóa tất cả?', 'Bạn có chắc muốn xóa toàn bộ giỏ hàng?', [
      { text: 'Hủy', style: 'cancel' },
      { text: 'Xóa', style: 'destructive', onPress: clearCart },
    ]);
  };

  // Empty cart
  if (items.length === 0) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
        <View style={styles.header}>
          <Text style={styles.title}>Giỏ hàng</Text>
        </View>
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>🛒</Text>
          <Text style={styles.emptyTitle}>Giỏ hàng trống</Text>
          <Text style={styles.emptySub}>Thêm sản phẩm để bắt đầu mua sắm</Text>
          <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('HomeTab')}>
            <Text style={styles.shopBtnText}>Khám phá ngay</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      {/* Success overlay */}
      {showSuccess && (
        <SuccessScreen total={lastTotal} method={lastPayment} onDone={handleSuccessDone} />
      )}

      {/* Payment modal */}
      <PaymentModal
        visible={showPaymentModal}
        selected={selectedPayment}
        onSelect={setSelectedPayment}
        onClose={() => setShowPaymentModal(false)}
        onConfirm={handleConfirmPayment}
        total={total}
      />

      <View style={styles.header}>
        <Text style={styles.title}>Giỏ hàng</Text>
        <TouchableOpacity onPress={handleClearAll}>
          <Text style={styles.clearText}>Xóa tất cả</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.subtitle}>{items.length} sản phẩm</Text>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Cart items */}
        {items.map(item => (
          <View key={item.id} style={styles.cartItem}>
            {/* Product image */}
            <View style={styles.itemImgWrap}>
              <Image
                source={productImages[item.imageKey]}
                style={styles.itemImg}
                resizeMode="cover"
              />
            </View>

            <View style={styles.itemInfo}>
              <Text style={styles.itemBrand}>{item.brand}</Text>
              <Text style={styles.itemName} numberOfLines={2}>{item.name}</Text>
              <Text style={styles.itemPrice}>{formatPrice(item.price)}</Text>
            </View>

            <View style={styles.itemActions}>
              <TouchableOpacity style={styles.deleteBtn} onPress={() => removeItem(item.id)}>
                <Text style={styles.deleteBtnText}>✕</Text>
              </TouchableOpacity>
              <View style={styles.qtyControls}>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQty(item.id, -1)}>
                  <Text style={styles.qtyBtnText}>−</Text>
                </TouchableOpacity>
                <Text style={styles.qtyNum}>{item.qty}</Text>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQty(item.id, 1)}>
                  <Text style={styles.qtyBtnText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}

        {/* Payment method quick select */}
        <TouchableOpacity style={styles.paymentRow} onPress={() => setShowPaymentModal(true)}>
          <Text style={{ fontSize: 20 }}>
            {PAYMENT_METHODS.find(p => p.id === selectedPayment)?.icon}
          </Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.paymentName}>
              {PAYMENT_METHODS.find(p => p.id === selectedPayment)?.name}
            </Text>
            <Text style={styles.paymentSub}>Nhấn để thay đổi</Text>
          </View>
          <Text style={{ color: '#4f8eff', fontSize: 13, fontWeight: '600' }}>Đổi ›</Text>
        </TouchableOpacity>

        {/* Order summary */}
        <View style={styles.summary}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Tạm tính</Text>
            <Text style={styles.summaryValue}>{formatPrice(subtotal)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Phí vận chuyển</Text>
            <Text style={styles.summaryValue}>{formatPrice(SHIPPING)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Giảm giá (5%)</Text>
            <Text style={[styles.summaryValue, { color: '#4caf50' }]}>−{formatPrice(discount)}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.summaryRow}>
            <Text style={styles.totalLabel}>Tổng cộng</Text>
            <Text style={styles.totalValue}>{formatPrice(total)}</Text>
          </View>
        </View>

        {/* Promo */}
        <View style={styles.promoRow}>
          <Text style={{ fontSize: 18 }}>🎟️</Text>
          <Text style={styles.promoText}>Nhập mã giảm giá</Text>
          <Text style={{ color: '#444', fontSize: 20 }}>›</Text>
        </View>

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Checkout button */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.checkoutBtn} onPress={handleCheckout} activeOpacity={0.85}>
          <Text style={styles.checkoutText}>
            Thanh toán — {formatPrice(total)}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 4 },
  title: { fontSize: 24, fontWeight: '700', color: '#fff' },
  clearText: { fontSize: 13, color: '#e94040' },
  subtitle: { fontSize: 13, color: '#555', paddingHorizontal: 20, marginBottom: 12 },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyIcon: { fontSize: 64 },
  emptyTitle: { fontSize: 18, fontWeight: '600', color: '#fff' },
  emptySub: { fontSize: 14, color: '#555' },
  shopBtn: { marginTop: 8, backgroundColor: '#4f8eff', paddingHorizontal: 28, paddingVertical: 14, borderRadius: 14 },
  shopBtnText: { color: '#fff', fontSize: 15, fontWeight: '600' },

  // Cart item
  cartItem: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: 16, marginBottom: 12,
    backgroundColor: '#12121a', borderRadius: 16,
    borderWidth: 1, borderColor: '#1e1e30', padding: 12, gap: 12,
  },
  itemImgWrap: {
    width: 72, height: 72, borderRadius: 12,
    overflow: 'hidden', backgroundColor: '#1a1a2e', flexShrink: 0,
  },
  itemImg: { width: '100%', height: '100%' },
  itemInfo: { flex: 1, minWidth: 0 },
  itemBrand: { fontSize: 11, color: '#4f8eff', marginBottom: 2 },
  itemName: { fontSize: 13, color: '#e0e0e0', fontWeight: '500', marginBottom: 4, lineHeight: 18 },
  itemPrice: { fontSize: 15, fontWeight: '700', color: '#fff' },
  itemActions: { alignItems: 'flex-end', gap: 8 },
  deleteBtn: { width: 28, height: 28, backgroundColor: '#2a1a1a', borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  deleteBtnText: { color: '#e94040', fontSize: 12, fontWeight: '700' },
  qtyControls: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  qtyBtn: { width: 28, height: 28, backgroundColor: '#1a1a2e', borderRadius: 7, borderWidth: 1, borderColor: '#2a2a45', alignItems: 'center', justifyContent: 'center' },
  qtyBtnText: { color: '#fff', fontSize: 16, lineHeight: 18 },
  qtyNum: { fontSize: 14, fontWeight: '700', color: '#fff', minWidth: 18, textAlign: 'center' },

  // Payment row
  paymentRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    marginHorizontal: 16, marginBottom: 12,
    backgroundColor: '#0d1b3e', borderRadius: 14,
    borderWidth: 1, borderColor: '#1a3a8f', padding: 14,
  },
  paymentName: { fontSize: 14, color: '#fff', fontWeight: '600', marginBottom: 2 },
  paymentSub: { fontSize: 11, color: '#4f8eff' },

  // Summary
  summary: { marginHorizontal: 16, marginBottom: 12, backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 16 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  summaryLabel: { fontSize: 13, color: '#777' },
  summaryValue: { fontSize: 13, color: '#ccc' },
  divider: { height: 1, backgroundColor: '#1e1e30', marginBottom: 12 },
  totalLabel: { fontSize: 16, fontWeight: '600', color: '#fff' },
  totalValue: { fontSize: 18, fontWeight: '700', color: '#4f8eff' },

  promoRow: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, backgroundColor: '#12121a', borderRadius: 14, borderWidth: 1, borderColor: '#1e1e30', padding: 14, gap: 12 },
  promoText: { flex: 1, fontSize: 14, color: '#888' },

  bottomBar: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, paddingBottom: 28, backgroundColor: '#0a0a0f', borderTopWidth: 1, borderTopColor: '#1a1a2e' },
  checkoutBtn: { backgroundColor: '#4f8eff', borderRadius: 16, paddingVertical: 18, alignItems: 'center' },
  checkoutText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});

export default CartScreen;
