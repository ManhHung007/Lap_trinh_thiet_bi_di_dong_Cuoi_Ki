import React, { useState, useMemo } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, SafeAreaView, StatusBar,
} from 'react-native';
import { products, categories } from '../data/products';
import ProductCard from '../components/ProductCard';

const ProductListScreen = ({ navigation }) => {
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('Tất cả');
  const [sortBy, setSortBy] = useState('default');

  const filtered = useMemo(() => {
    let result = products;

    // Filter by category
    if (selectedCat !== 'Tất cả') {
      result = result.filter(p => p.category === selectedCat);
    }

    // Filter by search
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        p => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q)
      );
    }

    // Sort
    if (sortBy === 'price_asc') result = [...result].sort((a, b) => a.price - b.price);
    if (sortBy === 'price_desc') result = [...result].sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') result = [...result].sort((a, b) => b.rating - a.rating);

    return result;
  }, [search, selectedCat, sortBy]);

  const sortOptions = [
    { key: 'default', label: 'Mặc định' },
    { key: 'price_asc', label: 'Giá tăng' },
    { key: 'price_desc', label: 'Giá giảm' },
    { key: 'rating', label: 'Đánh giá' },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Sản phẩm</Text>
        <View style={{ width: 38 }} />
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Tìm kiếm..."
          placeholderTextColor="#555"
          value={search}
          onChangeText={setSearch}
        />
        {!!search && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Text style={{ color: '#555', fontSize: 16 }}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Categories */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.catScroll}
      >
        {categories.map(cat => (
          <TouchableOpacity
            key={cat}
            style={[styles.catChip, selectedCat === cat && styles.catChipActive]}
            onPress={() => setSelectedCat(cat)}
          >
            <Text style={[styles.catLabel, selectedCat === cat && styles.catLabelActive]}>
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Sort */}
      <View style={styles.sortRow}>
        <Text style={styles.resultCount}>{filtered.length} sản phẩm</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {sortOptions.map(opt => (
            <TouchableOpacity
              key={opt.key}
              style={[styles.sortChip, sortBy === opt.key && styles.sortChipActive]}
              onPress={() => setSortBy(opt.key)}
            >
              <Text style={[styles.sortLabel, sortBy === opt.key && styles.sortLabelActive]}>
                {opt.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Product grid */}
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.grid}>
        {filtered.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🔍</Text>
            <Text style={styles.emptyText}>Không tìm thấy sản phẩm</Text>
          </View>
        ) : (
          filtered.reduce((rows, item, index) => {
            if (index % 2 === 0) {
              rows.push(
                <View key={index} style={styles.row}>
                  <ProductCard
                    product={item}
                    onPress={() => navigation.navigate('ProductDetail', { product: item })}
                  />
                  {filtered[index + 1] ? (
                    <ProductCard
                      product={filtered[index + 1]}
                      onPress={() => navigation.navigate('ProductDetail', { product: filtered[index + 1] })}
                    />
                  ) : (
                    <View style={{ flex: 1, margin: 6 }} />
                  )}
                </View>
              );
            }
            return rows;
          }, [])
        )}
        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#0a0a0f',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backText: {
    color: '#fff',
    fontSize: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a2e',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#2a2a45',
    gap: 10,
  },
  searchIcon: {
    fontSize: 16,
  },
  searchInput: {
    flex: 1,
    color: '#fff',
    fontSize: 14,
    padding: 0,
  },
  catScroll: {
    paddingHorizontal: 14,
    paddingBottom: 10,
    gap: 8,
  },
  catChip: {
    backgroundColor: '#1a1a2e',
    borderWidth: 1,
    borderColor: '#2a2a45',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  catChipActive: {
    backgroundColor: '#1a3a8f',
    borderColor: '#4f8eff',
  },
  catLabel: {
    fontSize: 12,
    color: '#ccc',
  },
  catLabelActive: {
    color: '#fff',
    fontWeight: '600',
  },
  sortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
    gap: 12,
  },
  resultCount: {
    fontSize: 12,
    color: '#666',
    flexShrink: 0,
  },
  sortChip: {
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: '#2a2a45',
    marginRight: 6,
  },
  sortChipActive: {
    backgroundColor: '#1a3a8f',
    borderColor: '#4f8eff',
  },
  sortLabel: {
    fontSize: 11,
    color: '#888',
  },
  sortLabelActive: {
    color: '#fff',
  },
  grid: {
    paddingHorizontal: 14,
  },
  row: {
    flexDirection: 'row',
  },
  empty: {
    alignItems: 'center',
    paddingTop: 80,
    gap: 12,
  },
  emptyIcon: {
    fontSize: 48,
  },
  emptyText: {
    fontSize: 15,
    color: '#555',
  },
});

export default ProductListScreen;
