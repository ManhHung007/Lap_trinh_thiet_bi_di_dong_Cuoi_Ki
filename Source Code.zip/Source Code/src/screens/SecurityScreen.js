import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, Switch, Alert, TextInput, Modal,
} from 'react-native';

const SecurityScreen = ({ navigation }) => {
  const [twoFA, setTwoFA] = useState(false);
  const [biometric, setBiometric] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const handleChangePass = () => {
    if (!oldPass || !newPass || !confirmPass) {
      Alert.alert('Lỗi', 'Vui lòng điền đầy đủ thông tin'); return;
    }
    if (newPass !== confirmPass) {
      Alert.alert('Lỗi', 'Mật khẩu mới không khớp'); return;
    }
    if (newPass.length < 6) {
      Alert.alert('Lỗi', 'Mật khẩu mới ít nhất 6 ký tự'); return;
    }
    setShowModal(false);
    setOldPass(''); setNewPass(''); setConfirmPass('');
    Alert.alert('✅ Thành công', 'Mật khẩu đã được cập nhật');
  };

  const loginHistory = [
    { device: 'Samsung Galaxy S24', time: 'Hôm nay, 13:05', location: 'Hà Nội, VN', current: true },
    { device: 'Chrome / Windows', time: 'Hôm qua, 09:22', location: 'Hà Nội, VN', current: false },
    { device: 'iPhone 14', time: '3 ngày trước', location: 'Hà Nội, VN', current: false },
  ];

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => navigation.goBack()}>
          <Text style={s.backText}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Bảo mật</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 20 }}>
        {/* Mật khẩu */}
        <Text style={s.sectionTitle}>Mật khẩu</Text>
        <TouchableOpacity style={s.row} onPress={() => setShowModal(true)}>
          <View style={s.rowIcon}><Text style={{ fontSize: 20 }}>🔑</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={s.rowLabel}>Đổi mật khẩu</Text>
            <Text style={s.rowSub}>Lần đổi gần nhất: 30 ngày trước</Text>
          </View>
          <Text style={s.arrow}>›</Text>
        </TouchableOpacity>

        {/* Bảo mật 2 lớp */}
        <Text style={s.sectionTitle}>Xác thực</Text>
        <View style={s.card}>
          <View style={s.switchRow}>
            <View style={s.rowIcon}><Text style={{ fontSize: 20 }}>📱</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.rowLabel}>Xác thực 2 bước (2FA)</Text>
              <Text style={s.rowSub}>Bảo mật bằng OTP qua SMS/email</Text>
            </View>
            <Switch value={twoFA} onValueChange={setTwoFA}
              trackColor={{ false: '#2a2a45', true: '#1a3a8f' }}
              thumbColor={twoFA ? '#4f8eff' : '#555'} />
          </View>
          <View style={s.divider} />
          <View style={s.switchRow}>
            <View style={s.rowIcon}><Text style={{ fontSize: 20 }}>👆</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.rowLabel}>Vân tay / Face ID</Text>
              <Text style={s.rowSub}>Đăng nhập nhanh bằng sinh trắc học</Text>
            </View>
            <Switch value={biometric} onValueChange={setBiometric}
              trackColor={{ false: '#2a2a45', true: '#1a3a8f' }}
              thumbColor={biometric ? '#4f8eff' : '#555'} />
          </View>
        </View>

        {/* Lịch sử đăng nhập */}
        <Text style={s.sectionTitle}>Lịch sử đăng nhập</Text>
        <View style={s.card}>
          {loginHistory.map((log, i) => (
            <View key={i}>
              <View style={s.logRow}>
                <View style={s.rowIcon}><Text style={{ fontSize: 20 }}>💻</Text></View>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={s.rowLabel}>{log.device}</Text>
                    {log.current && <View style={s.currentBadge}><Text style={s.currentText}>Hiện tại</Text></View>}
                  </View>
                  <Text style={s.rowSub}>{log.time} · {log.location}</Text>
                </View>
                {!log.current && (
                  <TouchableOpacity onPress={() => Alert.alert('Đăng xuất khỏi thiết bị này?', '', [
                    { text: 'Hủy', style: 'cancel' },
                    { text: 'Đăng xuất', style: 'destructive' },
                  ])}>
                    <Text style={{ color: '#e94040', fontSize: 12 }}>Xóa</Text>
                  </TouchableOpacity>
                )}
              </View>
              {i < loginHistory.length - 1 && <View style={s.divider} />}
            </View>
          ))}
        </View>

        {/* Xóa tài khoản */}
        <TouchableOpacity style={s.deleteAccount} onPress={() => Alert.alert('Xóa tài khoản', 'Bạn có chắc không? Hành động này không thể hoàn tác.', [
          { text: 'Hủy', style: 'cancel' },
          { text: 'Xóa', style: 'destructive' },
        ])}>
          <Text style={s.deleteText}>🗑 Xóa tài khoản</Text>
        </TouchableOpacity>
        <View style={{ height: 20 }} />
      </ScrollView>

      {/* Modal đổi mật khẩu */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modal}>
            <Text style={s.modalTitle}>Đổi mật khẩu</Text>
            {[
              { label: 'Mật khẩu hiện tại', val: oldPass, set: setOldPass },
              { label: 'Mật khẩu mới', val: newPass, set: setNewPass },
              { label: 'Xác nhận mật khẩu mới', val: confirmPass, set: setConfirmPass },
            ].map((f, i) => (
              <View key={i} style={s.modalInput}>
                <TextInput
                  style={s.input}
                  placeholder={f.label}
                  placeholderTextColor="#444"
                  secureTextEntry
                  value={f.val}
                  onChangeText={f.set}
                />
              </View>
            ))}
            <View style={s.modalBtns}>
              <TouchableOpacity style={s.cancelBtn} onPress={() => setShowModal(false)}>
                <Text style={s.cancelText}>Hủy</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.confirmBtn} onPress={handleChangePass}>
                <Text style={s.confirmText}>Xác nhận</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  back: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  title: { fontSize: 17, fontWeight: '700', color: '#fff' },
  sectionTitle: { fontSize: 12, color: '#555', textTransform: 'uppercase', letterSpacing: 1 },
  card: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30' },
  row: { backgroundColor: '#12121a', borderRadius: 16, borderWidth: 1, borderColor: '#1e1e30', padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  switchRow: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  logRow: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  rowIcon: { width: 38, height: 38, backgroundColor: '#1a1a2e', borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  rowLabel: { fontSize: 14, color: '#ddd', fontWeight: '500', marginBottom: 2 },
  rowSub: { fontSize: 12, color: '#555' },
  arrow: { fontSize: 20, color: '#333' },
  divider: { height: 1, backgroundColor: '#1e1e30', marginHorizontal: 14 },
  currentBadge: { backgroundColor: '#0d2a0d', borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2 },
  currentText: { fontSize: 10, color: '#22c55e', fontWeight: '600' },
  deleteAccount: { borderWidth: 1, borderColor: '#3a2020', borderRadius: 14, paddingVertical: 16, alignItems: 'center', backgroundColor: '#2a1212' },
  deleteText: { color: '#e94040', fontSize: 14, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#12121a', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, borderWidth: 1, borderColor: '#1e1e30' },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 20 },
  modalInput: { backgroundColor: '#1a1a2e', borderRadius: 12, borderWidth: 1, borderColor: '#2a2a45', marginBottom: 12 },
  input: { color: '#fff', fontSize: 14, padding: 14 },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 8 },
  cancelBtn: { flex: 1, backgroundColor: '#1a1a2e', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  cancelText: { color: '#888', fontSize: 15, fontWeight: '600' },
  confirmBtn: { flex: 1, backgroundColor: '#4f8eff', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  confirmText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});

export default SecurityScreen;
