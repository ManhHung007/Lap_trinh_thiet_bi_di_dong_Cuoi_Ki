import { productImages } from '../data/products';
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Image, ActivityIndicator,
} from 'react-native';
import { formatPrice } from '../data/products';
import { useCart } from '../context/CartContext';

const ProductCard = ({ product, onPress }) => {
  const { addItem } = useCart();
  const [imgLoading, setImgLoading] = useState(true);
  const [imgError, setImgError] = useState(false);

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.85}>
      {/* Image */}
      <View style={styles.imgBox}>
        {!!product.badge && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{product.badge}</Text>
          </View>
        )}

        {imgLoading && !imgError && (
          <ActivityIndicator
            style={styles.loader}
            color="#4f8eff"
            size="small"
          />
        )}

        {!imgError ? (
          <Image
            source={productImages[product.imageKey]}
            style={styles.img}
            resizeMode="cover"
            onLoad={() => setImgLoading(false)}
            onError={() => { setImgLoading(false); setImgError(true); }}
          />
        ) : (
          // Fallback nếu ảnh lỗi
          <View style={styles.imgFallback}>
            <Text style={styles.fallbackText}>🖼️</Text>
          </View>
        )}
      </View>

      {/* Info */}
      <View style={styles.info}>
        <Text style={styles.brand}>{product.brand}</Text>
        <Text style={styles.name} numberOfLines={2}>{product.name}</Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Text style={styles.star}>★</Text>
          <Text style={styles.ratingNum}>{product.rating}</Text>
          <Text style={styles.reviews}>({product.reviews.toLocaleString('vi-VN')})</Text>
        </View>

        <View style={styles.footer}>
          <View>
            <Text style={styles.price}>{formatPrice(product.price)}</Text>
            <Text style={styles.oldPrice}>{formatPrice(product.oldPrice)}</Text>
          </View>
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => addItem(product)}
            activeOpacity={0.8}
          >
            <Text style={styles.addBtnText}>+</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: '#12121a',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#1e1e30',
    overflow: 'hidden',
    margin: 6,
  },
  imgBox: {
    backgroundColor: '#1a1a2e',
    height: 140,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  img: {
    width: '100%',
    height: '100%',
  },
  loader: {
    position: 'absolute',
    zIndex: 1,
  },
  imgFallback: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1a1a2e',
  },
  fallbackText: {
    fontSize: 40,
  },
  badge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#e94040',
    borderRadius: 6,
    paddingHorizontal: 7,
    paddingVertical: 2,
    zIndex: 2,
  },
  badgeText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  info: {
    padding: 10,
  },
  brand: {
    fontSize: 10,
    color: '#4f8eff',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  name: {
    fontSize: 13,
    color: '#e0e0e0',
    fontWeight: '500',
    marginVertical: 3,
    lineHeight: 18,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginBottom: 6,
  },
  star: {
    color: '#f5c518',
    fontSize: 11,
  },
  ratingNum: {
    fontSize: 11,
    color: '#ccc',
    fontWeight: '600',
  },
  reviews: {
    fontSize: 10,
    color: '#555',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontSize: 13,
    fontWeight: '700',
    color: '#fff',
  },
  oldPrice: {
    fontSize: 10,
    color: '#555',
    textDecorationLine: 'line-through',
  },
  addBtn: {
    width: 30,
    height: 30,
    backgroundColor: '#4f8eff',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnText: {
    color: '#fff',
    fontSize: 20,
    lineHeight: 24,
    fontWeight: '300',
  },
});

export default ProductCard;
