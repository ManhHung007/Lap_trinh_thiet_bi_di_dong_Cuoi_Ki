# TechShop - Ứng dụng mua sắm thiết bị điện tử
### React Native + Expo

---

## Cấu trúc dự án

```
ShopApp/
├── App.js                        # Root component
├── package.json
└── src/
    ├── data/
    │   └── products.js           # Dữ liệu sản phẩm + helper
    ├── context/
    │   └── CartContext.js        # Global cart state (useReducer)
    ├── components/
    │   └── ProductCard.js        # Card sản phẩm tái sử dụng
    ├── screens/
    │   ├── HomeScreen.js         # Trang chủ + banner + lọc danh mục
    │   ├── ProductListScreen.js  # Danh sách + tìm kiếm + sắp xếp
    │   ├── ProductDetailScreen.js# Chi tiết sản phẩm + thêm giỏ
    │   ├── CartScreen.js         # Giỏ hàng + tính tiền
    │   └── ProfileScreen.js      # Hồ sơ cá nhân
    └── navigation/
        └── AppNavigator.js       # Bottom tab + nested stack navigator
```

---

## Cài đặt và chạy

### 1. Cài Expo CLI
```bash
npm install -g expo-cli
```

### 2. Tạo project Expo mới
```bash
npx create-expo-app ShopApp
cd ShopApp
```

### 3. Copy các file vào đúng thư mục theo cấu trúc trên

### 4. Cài dependencies
```bash
npm install @react-navigation/native @react-navigation/bottom-tabs @react-navigation/native-stack react-native-screens react-native-safe-area-context
```

### 5. Chạy ứng dụng
```bash
npx expo start
```
Scan QR bằng app **Expo Go** trên điện thoại, hoặc nhấn `a` để mở Android Emulator.

---

## Tính năng

| Màn hình | Tính năng |
|----------|-----------|
| Home | Banner khuyến mãi, lọc danh mục, danh sách sản phẩm |
| ProductList | Tìm kiếm realtime, lọc danh mục, sắp xếp theo giá/đánh giá |
| ProductDetail | Thông số kỹ thuật, chọn số lượng, thêm vào giỏ hàng |
| Cart | Quản lý giỏ, tính phí ship, giảm giá 5%, đặt hàng |
| Profile | Thông tin user, thống kê, menu cài đặt |

## Công nghệ sử dụng
- React Native + Expo
- React Navigation (Bottom Tabs + Native Stack)
- Context API + useReducer (quản lý giỏ hàng)
- StyleSheet API
